#!/usr/bin/env bash
# 在 macOS 26 + Go 1.22 上，内部链接器产出的 Mach-O 缺少 LC_UUID 会被 dyld 拒绝。
# 这里强制走外部链接器（clang）并做 ad-hoc 签名，保证可执行。
set -euo pipefail

cd "$(dirname "$0")"

export GOSUMDB=off
export GOTOOLCHAIN=local
export GOPROXY="${GOPROXY:-https://goproxy.cn,direct}"
export CGO_ENABLED=1

go build -ldflags='-linkmode=external' -o copytrade ./cmd/copytrade

# ad-hoc 签名，避免 macOS Gatekeeper 直接 SIGKILL
if command -v codesign >/dev/null 2>&1; then
  codesign --force --sign - copytrade
fi

echo "build ok: $(ls -lh copytrade | awk '{print $5}')"
