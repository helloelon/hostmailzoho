// Package assets 内嵌前端静态资源（web 目录），编译进二进制，部署无需额外文件。
package assets

import "embed"

//go:embed web
var Web embed.FS
