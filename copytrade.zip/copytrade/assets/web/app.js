// CopyTrade admin 前端逻辑
const $ = (id) => document.getElementById(id);

// ---------- 提醒音（Web Audio，无需外部资源） ----------
let audioCtx = null;
function playAlert() {
  try {
    audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
    if (audioCtx.state === 'suspended') audioCtx.resume();
    const beep = (freq, start, dur) => {
      const t0 = audioCtx.currentTime + start;
      const o = audioCtx.createOscillator();
      const g = audioCtx.createGain();
      o.type = 'sine'; o.frequency.value = freq;
      o.connect(g); g.connect(audioCtx.destination);
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(0.35, t0 + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      o.start(t0); o.stop(t0 + dur + 0.02);
    };
    beep(880, 0, 0.18);
    beep(1175, 0.22, 0.22);
  } catch (e) { /* 忽略不支持音频的环境 */ }
}
// 用户首次交互后解锁音频上下文
document.addEventListener('click', () => { if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume(); }, { once: true });

function fmtTime(ms) {
  if (!ms) return '-';
  const d = new Date(Number(ms));
  const p = (n) => String(n).padStart(2, '0');
  return `${p(d.getMonth()+1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

// ---------- Tabs ----------
document.querySelectorAll('.tab').forEach(t => {
  t.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(x => x.classList.remove('active'));
    document.querySelectorAll('.tab-body').forEach(x => x.classList.add('hidden'));
    t.classList.add('active');
    $('tab-' + t.dataset.tab).classList.remove('hidden');
  });
});

// ---------- Config ----------
async function loadConfig() {
  const r = await fetch('/api/copy-config');
  if (r.status === 401) { location.href = '/login'; return; }
  const c = await r.json();
  $('cfgEnabled').checked = !!c.enabled;
  $('cfgMargin').value = c.margin_usdt;
  $('cfgLeverage').value = c.leverage;
  $('cfgType').value = c.order_type;
  // 填充交易所下拉（“全部”在最前）
  const sel = $('oExchange');
  const cur = sel.value;
  sel.innerHTML = '';
  const all = document.createElement('option'); all.value = '__all__'; all.textContent = '全部'; sel.appendChild(all);
  (c.exchanges || []).forEach(n => {
    const o = document.createElement('option'); o.value = n; o.textContent = n; sel.appendChild(o);
  });
  if (cur) sel.value = cur;
}
$('cfgSave').addEventListener('click', async () => {
  const body = {
    enabled: $('cfgEnabled').checked,
    margin_usdt: Number($('cfgMargin').value),
    leverage: Number($('cfgLeverage').value),
    order_type: $('cfgType').value,
  };
  const r = await fetch('/api/copy-config', { method: 'PUT', headers: {'Content-Type':'application/json'}, body: JSON.stringify(body) });
  const hint = $('orderHint');
  if (r.ok) hint.textContent = '配置已保存';
  else { const j = await r.json().catch(()=>({})); hint.textContent = '保存失败: ' + (j.error||''); }
});
$('logoutBtn').addEventListener('click', async () => { await fetch('/api/logout'); location.href = '/login'; });

// ---------- Render ----------
function renderPositions(list) {
  const tb = $('posBody');
  tb.innerHTML = '';
  (list || []).forEach(p => {
    const tr = document.createElement('tr');
    const isShort = p.positionSide === 'SHORT';
    const sideCls = isShort ? 'side-sell' : 'side-buy';
    const closeLabel = isShort ? '平空' : '平多';
    tr.innerHTML = `<td>${p.exchange}</td><td>${p.symbol}</td>
      <td class="${sideCls}">${isShort ? '空' : '多'}</td><td>${p.quantity}</td>
      <td>${p.entryPrice}</td><td>${p.markPrice}</td><td>${p.unrealizedPnl}</td>
      <td><button class="btn-mini danger" data-close='${JSON.stringify({exchange:p.exchange,symbol:p.symbol,position_side:p.positionSide})}'>${closeLabel}</button></td>`;
    tb.appendChild(tr);
  });
  tb.querySelectorAll('[data-close]').forEach(b => b.addEventListener('click', () => doClose(JSON.parse(b.dataset.close))));
}

function renderOpenOrders(list) {
  const tb = $('ordBody');
  tb.innerHTML = '';
  (list || []).forEach(o => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${o.exchange}</td><td>${o.symbol}</td>
      <td class="${o.side==='BUY'?'side-buy':'side-sell'}">${o.side} ${o.positionSide||''}</td>
      <td>${o.type}</td><td>${o.quantity}</td><td>${o.price}</td><td>${o.status}</td>
      <td><button class="btn-mini danger" data-cancel='${JSON.stringify({exchange:o.exchange,symbol:o.symbol,order_id:o.orderId})}'>撤单</button></td>`;
    tb.appendChild(tr);
  });
  tb.querySelectorAll('[data-cancel]').forEach(b => b.addEventListener('click', () => doCancel(JSON.parse(b.dataset.cancel))));
}

// BUY LONG 开多 / SELL SHORT 开空 / SELL LONG 平多 / BUY SHORT 平空
function leaderDirCN(side, posSide) {
  const s = (side || '').toUpperCase(), p = (posSide || '').toUpperCase();
  if (s === 'BUY' && p === 'LONG') return '开多';
  if (s === 'SELL' && p === 'SHORT') return '开空';
  if (s === 'SELL' && p === 'LONG') return '平多';
  if (s === 'BUY' && p === 'SHORT') return '平空';
  return side || '-';
}

let prevLeaderKeys = null;
function leaderKey(o) { return `${o.symbol}|${o.orderTime}|${o.executedQty}|${o.avgPrice}`; }
function onLeaderData(list) {
  const keys = new Set((list || []).map(leaderKey));
  if (prevLeaderKeys !== null) {
    for (const k of keys) {
      if (!prevLeaderKeys.has(k)) { playAlert(); break; }
    }
  }
  prevLeaderKeys = keys;
  renderLeader(list);
}

function renderLeader(list) {
  const tb = $('leaderBody');
  const sorted = (list || []).slice().sort((a,b) => b.orderTime - a.orderTime);
  $('leaderCount').textContent = sorted.length ? `共 ${sorted.length} 条` : '';
  tb.innerHTML = '';
  sorted.forEach(o => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${fmtTime(o.orderTime)}</td><td>${o.symbol}</td>
      <td class="${o.side==='BUY'?'side-buy':'side-sell'}">${leaderDirCN(o.side, o.positionSide)}</td>
      <td>${o.type}</td><td>${o.executedQty}</td><td>${o.avgPrice}</td>
      <td style="color:${o.totalPnl>0?'var(--green)':o.totalPnl<0?'var(--red)':'inherit'}">${o.totalPnl}</td>`;
    tb.appendChild(tr);
  });
}

function renderCopied(list) {
  const tb = $('copiedBody');
  const sorted = (list || []).slice().sort((a,b) => b.time - a.time).slice(0, 60);
  tb.innerHTML = '';
  sorted.forEach(r => {
    const tr = document.createElement('tr');
    const st = r.error ? `<span style="color:var(--red)">失败</span>` : r.status;
    tr.innerHTML = `<td>${fmtTime(r.time)}</td><td>${r.exchange}</td><td>${r.symbol}</td>
      <td>${r.action}</td><td>${r.quantity||'-'}</td><td>${r.price||'-'}</td><td>${st}</td>`;
    tb.appendChild(tr);
  });
}

// ---------- Actions ----------
async function doClose(payload) {
  if (!confirm(`确认平仓 ${payload.exchange} ${payload.symbol} ${payload.position_side} ?`)) return;
  const r = await fetch('/api/close', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
  const j = await r.json().catch(()=>({}));
  $('orderHint').textContent = r.ok ? `平仓已提交: ${j.orderId||''}` : '平仓失败: ' + (j.error||'');
}
async function doCancel(payload) {
  const r = await fetch('/api/cancel', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
  const j = await r.json().catch(()=>({}));
  $('orderHint').textContent = r.ok ? `撤单成功: ${j.orderId||''}` : '撤单失败: ' + (j.error||'');
}

$('orderForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const body = {
    exchange: $('oExchange').value, symbol: $('oSymbol').value.trim().toUpperCase(),
    direction: $('oDir').value,
    type: $('oType').value, quantity: $('oQty').value, price: $('oPrice').value,
  };
  const hint = $('orderHint');
  hint.textContent = '下单中...';
  const r = await fetch('/api/order', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) });
  const j = await r.json().catch(()=>({}));
  if (r.ok) {
    if (j.results) {
      const ok = j.results.filter(x => !x.error).length;
      const fail = j.results.length - ok;
      hint.textContent = `全部下单完成：成功 ${ok}，失败 ${fail}`;
    } else {
      hint.textContent = `下单成功: ${j.orderId||''} (${j.status||''})`;
    }
    $('oQty').value = '';
  } else {
    hint.textContent = '下单失败: ' + (j.error || '');
  }
});

// ---------- SSE ----------
function connect() {
  const es = new EventSource('/api/stream');
  es.onmessage = (ev) => {
    let msg; try { msg = JSON.parse(ev.data); } catch { return; }
    switch (msg.type) {
      case 'positions':
        renderPositions(msg.data.positions);
        renderOpenOrders(msg.data.openOrders);
        break;
      case 'leader': onLeaderData(msg.data); break;
      case 'copied': renderCopied(msg.data); break;
      case 'config':
        if (msg.data) { $('cfgEnabled').checked = !!msg.data.enabled; $('cfgMargin').value=msg.data.margin_usdt; $('cfgLeverage').value=msg.data.leverage; $('cfgType').value=msg.data.order_type; }
        break;
      case 'leader_error': $('leaderCount').textContent = '拉取失败: ' + msg.data; break;
    }
  };
  es.onerror = () => { /* 浏览器会自动重连 */ };
}

(async () => {
  await loadConfig();
  connect();
})();
