package server

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/domigo/copytrade/internal/broker"
	"github.com/domigo/copytrade/internal/model"
)

// allExchangeKey 前端“全部”选项对应的特殊值
const allExchangeKey = "__all__"

func (s *Server) serveLogin(w http.ResponseWriter, r *http.Request) {
	s.serveFile(w, "login.html")
}

func (s *Server) serveAdmin(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		// 未知路径回退到管理页（前端单页）
	}
	s.serveFile(w, "admin.html")
}

func (s *Server) serveFile(w http.ResponseWriter, name string) {
	f, err := s.webFS.Open(name)
	if err != nil {
		http.NotFound(w, nil)
		return
	}
	defer f.Close()
	w.Header().Set("Content-Type", contentTypeOf(name))
	io.Copy(w, f)
}

func contentTypeOf(name string) string {
	switch {
	case len(name) > 5 && name[len(name)-5:] == ".html":
		return "text/html; charset=utf-8"
	case len(name) > 3 && name[len(name)-3:] == ".css":
		return "text/css; charset=utf-8"
	case len(name) > 3 && name[len(name)-3:] == ".js":
		return "application/javascript; charset=utf-8"
	}
	return "application/octet-stream"
}

// ---------- 登录 ----------

func (s *Server) handleLogin(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeErr(w, 405, "method not allowed")
		return
	}
	_ = r.ParseForm()
	user := r.FormValue("username")
	pass := r.FormValue("password")
	tok, ok := s.auth.login(user, pass)
	if !ok {
		writeErr(w, 401, "用户名或密码错误")
		return
	}
	http.SetCookie(w, &http.Cookie{
		Name: sessionCookie, Value: tok, Path: "/",
		HttpOnly: true, SameSite: http.SameSiteLaxMode, MaxAge: int(sessionTTL.Seconds()),
	})
	writeJSON(w, map[string]any{"ok": true})
}

func (s *Server) handleLogout(w http.ResponseWriter, r *http.Request) {
	if c, err := r.Cookie(sessionCookie); err == nil {
		s.auth.revoke(c.Value)
	}
	http.SetCookie(w, &http.Cookie{Name: sessionCookie, Value: "", Path: "/", MaxAge: -1})
	writeJSON(w, map[string]any{"ok": true})
}

// ---------- SSE ----------

func (s *Server) handleStream(w http.ResponseWriter, r *http.Request) {
	flusher, ok := w.(http.Flusher)
	if !ok {
		writeErr(w, 500, "streaming unsupported")
		return
	}
	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Cache-Control", "no-cache")
	w.Header().Set("Connection", "keep-alive")
	w.Header().Set("X-Accel-Buffering", "no")

	ch := s.hub.subscribe()
	defer s.hub.unsubscribe(ch)

	send := func(msg string) {
		io.WriteString(w, "data: "+msg+"\n\n")
		flusher.Flush()
	}

	// 连接即推快照
	if b, err := json.Marshal(map[string]any{"type": "leader", "data": s.leader.Last()}); err == nil {
		send(string(b))
	}
	if b, err := json.Marshal(map[string]any{"type": "copied", "data": s.store.CopiedList()}); err == nil {
		send(string(b))
	}
	if b, err := json.Marshal(map[string]any{"type": "config", "data": s.copyConfigSnapshot()}); err == nil {
		send(string(b))
	}

	hb := time.NewTicker(25 * time.Second)
	defer hb.Stop()
	for {
		select {
		case <-r.Context().Done():
			return
		case msg := <-ch:
			send(msg)
		case <-hb.C:
			io.WriteString(w, ": heartbeat\n\n")
			flusher.Flush()
		}
	}
}

// ---------- REST ----------

func (s *Server) handlePositions(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, s.collectPositions(r.URL.Query().Get("exchange")))
}

func (s *Server) handleOpenOrders(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, s.collectOpenOrders(r.URL.Query().Get("exchange")))
}

func (s *Server) handleLeader(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, s.leader.Last())
}

// handleLeaderMonitor 免登录 + CORS，供独立 monitor.html 跨域轮询带单者成交
func (s *Server) handleLeaderMonitor(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "GET, OPTIONS")
	w.Header().Set("Access-Control-Max-Age", "600")
	w.Header().Set("Cache-Control", "no-store")
	if r.Method == http.MethodOptions {
		w.WriteHeader(http.StatusNoContent)
		return
	}
	if r.Method != http.MethodGet {
		writeErr(w, 405, "method not allowed")
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 20*time.Second)
	defer cancel()
	orders, err := s.leader.Latest(ctx)
	if err != nil {
		writeErr(w, http.StatusBadGateway, err.Error())
		return
	}
	writeJSON(w, orders)
}

func (s *Server) handleCopied(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, s.store.CopiedList())
}

// handleNotifyTest 手动触发一条企业微信测试消息，验证 webhook 链路
func (s *Server) handleNotifyTest(w http.ResponseWriter, r *http.Request) {
	if s.notifier == nil || !s.notifier.Enabled() {
		writeErr(w, 400, "企业微信通知未启用（请配置 notify.wechat.webhook）")
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 15*time.Second)
	defer cancel()
	content := fmt.Sprintf(
		"【copytrade】通知测试\n企业微信 webhook 链路正常\n时间：%s",
		time.Now().Format("2006-01-02 15:04:05"),
	)
	if err := s.notifier.SendText(ctx, content); err != nil {
		log.Printf("[server] notify test 失败: %v", err)
		writeErr(w, 502, "发送失败: "+err.Error())
		return
	}
	writeJSON(w, map[string]any{"ok": true, "msg": "测试消息已发送，请查看企业微信群"})
}

func (s *Server) collectPositions(name string) []model.Position {
	var out []model.Position
	for k, ex := range s.exchanges {
		if name != "" && k != name {
			continue
		}
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		ps, err := ex.GetPositions(ctx)
		cancel()
		if err == nil {
			out = append(out, ps...)
		}
	}
	return out
}

func (s *Server) collectOpenOrders(name string) []model.OpenOrder {
	var out []model.OpenOrder
	for k, ex := range s.exchanges {
		if name != "" && k != name {
			continue
		}
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		oo, err := ex.GetOpenOrders(ctx)
		cancel()
		if err == nil {
			out = append(out, oo...)
		}
	}
	return out
}

func (s *Server) copyConfigSnapshot() map[string]any {
	enabled, margin, lev, ot := s.engine.Runtime().Snapshot()
	return map[string]any{
		"enabled":    enabled,
		"margin_usdt": margin,
		"leverage":   lev,
		"order_type": ot,
		"exchanges":  s.cfg.Copy.Exchanges,
	}
}

func (s *Server) handleCopyConfig(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodGet {
		writeJSON(w, s.copyConfigSnapshot())
		return
	}
	if r.Method != http.MethodPut {
		writeErr(w, 405, "method not allowed")
		return
	}
	var body struct {
		Enabled    bool    `json:"enabled"`
		MarginUSDT float64 `json:"margin_usdt"`
		Leverage   int     `json:"leverage"`
		OrderType  string  `json:"order_type"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		writeErr(w, 400, "bad json: "+err.Error())
		return
	}
	if err := s.engine.Runtime().Update(body.Enabled, body.MarginUSDT, body.Leverage, body.OrderType); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	if b, err := json.Marshal(map[string]any{"type": "config", "data": s.copyConfigSnapshot()}); err == nil {
		s.hub.broadcast(string(b))
	}
	writeJSON(w, map[string]any{"ok": true})
}

func (s *Server) handleOrder(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeErr(w, 405, "method not allowed")
		return
	}
	var body struct {
		Exchange     string `json:"exchange"`
		Symbol       string `json:"symbol"`
		Direction    string `json:"direction"` // LONG / SHORT，优先：自动适配开多/开空
		Side         string `json:"side"`
		PositionSide string `json:"position_side"`
		Type         string `json:"type"`
		Quantity     string `json:"quantity"`
		Price        string `json:"price"`
		ReduceOnly   bool   `json:"reduce_only"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		writeErr(w, 400, "bad json: "+err.Error())
		return
	}
	// direction 优先：由单一模板生成开多/开空参数，禁止 reduceOnly
	side, posSide, reduceOnly := body.Side, body.PositionSide, body.ReduceOnly
	switch strings.ToUpper(body.Direction) {
	case "LONG":
		side, posSide = broker.HedgeParams(broker.ActOpen, broker.DirLong)
		reduceOnly = false
	case "SHORT":
		side, posSide = broker.HedgeParams(broker.ActOpen, broker.DirShort)
		reduceOnly = false
	}
	if side == "" || posSide == "" {
		writeErr(w, 400, "缺少 direction 或 side/position_side")
		return
	}
	_, margin, lev, _ := s.engine.Runtime().Snapshot()
	mkReq := func() model.OrderReq {
		return model.OrderReq{
			Symbol: body.Symbol, Side: side, PositionSide: posSide,
			Type: body.Type, Quantity: body.Quantity, Price: body.Price, ReduceOnly: reduceOnly,
		}
	}
	// 全部交易所并发下单
	if body.Exchange == allExchangeKey {
		var (
			wg  sync.WaitGroup
			mu  sync.Mutex
			res []map[string]any
		)
		for name := range s.exchanges {
			wg.Add(1)
			go func(name string) {
				defer wg.Done()
				resp, err := s.engine.ManualPlace(r.Context(), name, mkReq(), margin, lev)
				mu.Lock()
				defer mu.Unlock()
				item := map[string]any{"exchange": name}
				if err != nil {
					item["error"] = err.Error()
				} else {
					item["orderId"] = resp.OrderID
					item["status"] = resp.Status
				}
				res = append(res, item)
			}(name)
		}
		wg.Wait()
		writeJSON(w, map[string]any{"results": res})
		return
	}
	resp, err := s.engine.ManualPlace(r.Context(), body.Exchange, mkReq(), margin, lev)
	if err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	writeJSON(w, resp)
}

func (s *Server) handleClose(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeErr(w, 405, "method not allowed")
		return
	}
	var body struct {
		Exchange     string `json:"exchange"`
		Symbol       string `json:"symbol"`
		PositionSide string `json:"position_side"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		writeErr(w, 400, "bad json: "+err.Error())
		return
	}
	ex, ok := s.exchanges[body.Exchange]
	if !ok {
		writeErr(w, 400, "交易所不存在: "+body.Exchange)
		return
	}
	resp, err := ex.ClosePosition(r.Context(), body.Symbol, body.PositionSide)
	if err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	writeJSON(w, resp)
}

func (s *Server) handleCancel(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeErr(w, 405, "method not allowed")
		return
	}
	var body struct {
		Exchange string `json:"exchange"`
		Symbol   string `json:"symbol"`
		OrderID  string `json:"order_id"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		writeErr(w, 400, "bad json: "+err.Error())
		return
	}
	ex, ok := s.exchanges[body.Exchange]
	if !ok {
		writeErr(w, 400, "交易所不存在: "+body.Exchange)
		return
	}
	resp, err := ex.CancelOrder(r.Context(), body.Symbol, body.OrderID)
	if err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	writeJSON(w, resp)
}
