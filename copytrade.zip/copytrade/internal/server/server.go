package server

import (
	"context"
	"crypto/rand"
	"crypto/subtle"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io/fs"
	"log"
	"net/http"
	"sync"
	"time"

	"github.com/domigo/copytrade/assets"
	"github.com/domigo/copytrade/internal/broker"
	"github.com/domigo/copytrade/internal/config"
	"github.com/domigo/copytrade/internal/copy"
	"github.com/domigo/copytrade/internal/leader"
	"github.com/domigo/copytrade/internal/model"
	"github.com/domigo/copytrade/internal/notify"
	"github.com/domigo/copytrade/internal/store"
	"golang.org/x/crypto/bcrypt"
)

const sessionCookie = "ct_session"
const sessionTTL = 12 * time.Hour

type Server struct {
	cfg       *config.Config
	engine    *copy.Engine
	exchanges map[string]broker.Exchange
	leader    *leader.Fetcher
	store     *store.State
	notifier  *notify.WeChat
	auth      *Auth
	hub       *Hub
	webFS     fs.FS
}

func New(cfg *config.Config, engine *copy.Engine, exchanges map[string]broker.Exchange, lf *leader.Fetcher, st *store.State, notifier *notify.WeChat) *Server {
	sub, err := fs.Sub(assets.Web, "web")
	if err != nil {
		log.Fatalf("embed web: %v", err)
	}
	s := &Server{
		cfg: cfg, engine: engine, exchanges: exchanges, leader: lf, store: st, notifier: notifier,
		auth: newAuth(cfg.Admin), hub: newHub(), webFS: sub,
	}
	engine.SetSink(s.onEngineEvent)
	return s
}

func (s *Server) Handler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/login", s.serveLogin)
	mux.Handle("/assets/", http.StripPrefix("/assets/", http.FileServer(http.FS(s.webFS))))
	mux.HandleFunc("/api/login", s.handleLogin)
	// 免登录公开端点（带单者数据本身公开），允许独立 monitor.html 跨域访问
	mux.HandleFunc("/api/leader-monitor", s.handleLeaderMonitor)

	mux.HandleFunc("/", s.auth.middleware(s.serveAdmin))
	mux.HandleFunc("/api/logout", s.auth.middleware(s.handleLogout))
	mux.HandleFunc("/api/stream", s.auth.middleware(s.handleStream))
	mux.HandleFunc("/api/positions", s.auth.middleware(s.handlePositions))
	mux.HandleFunc("/api/open-orders", s.auth.middleware(s.handleOpenOrders))
	mux.HandleFunc("/api/leader", s.auth.middleware(s.handleLeader))
	mux.HandleFunc("/api/copied", s.auth.middleware(s.handleCopied))
	mux.HandleFunc("/api/copy-config", s.auth.middleware(s.handleCopyConfig))
	mux.HandleFunc("/api/order", s.auth.middleware(s.handleOrder))
	mux.HandleFunc("/api/close", s.auth.middleware(s.handleClose))
	mux.HandleFunc("/api/cancel", s.auth.middleware(s.handleCancel))
	mux.HandleFunc("/api/notify/test", s.auth.middleware(s.handleNotifyTest))
	return mux
}

// Start 启动 SSE 与定时刷新（非阻塞）
func (s *Server) Start(ctx context.Context) {
	go s.hub.run()
	go s.refreshLoop(ctx)
}

func (s *Server) onEngineEvent(kind string, payload any) {
	b, _ := json.Marshal(map[string]any{"type": kind, "data": payload})
	s.hub.broadcast(string(b))
}

// refreshLoop 周期性拉取持仓/挂单并通过 SSE 推送
func (s *Server) refreshLoop(ctx context.Context) {
	t := time.NewTicker(3 * time.Second)
	defer t.Stop()
	s.pushPositions()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			s.pushPositions()
		}
	}
}

func (s *Server) pushPositions() {
	type agg struct {
		Positions  []model.Position  `json:"positions"`
		OpenOrders []model.OpenOrder `json:"openOrders"`
	}
	var a agg
	for _, ex := range s.exchanges {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		ps, err := ex.GetPositions(ctx)
		if err == nil {
			a.Positions = append(a.Positions, ps...)
		}
		oo, err := ex.GetOpenOrders(ctx)
		cancel()
		if err == nil {
			a.OpenOrders = append(a.OpenOrders, oo...)
		}
	}
	b, _ := json.Marshal(map[string]any{"type": "positions", "data": a})
	s.hub.broadcast(string(b))
}

// ---------- Auth ----------

type Auth struct {
	mu     sync.Mutex
	tokens map[string]time.Time
	cfg    config.Admin
}

func newAuth(cfg config.Admin) *Auth {
	a := &Auth{tokens: map[string]time.Time{}, cfg: cfg}
	go a.cleanup()
	return a
}

func (a *Auth) cleanup() {
	t := time.NewTicker(time.Hour)
	defer t.Stop()
	for range t.C {
		now := time.Now()
		a.mu.Lock()
		for k, exp := range a.tokens {
			if now.After(exp) {
				delete(a.tokens, k)
			}
		}
		a.mu.Unlock()
	}
}

func (a *Auth) login(user, pass string) (string, bool) {
	if subtle.ConstantTimeCompare([]byte(user), []byte(a.cfg.Username)) != 1 {
		return "", false
	}
	if !a.verify(pass) {
		return "", false
	}
	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		return "", false
	}
	tok := hex.EncodeToString(b)
	a.mu.Lock()
	a.tokens[tok] = time.Now().Add(sessionTTL)
	a.mu.Unlock()
	return tok, true
}

func (a *Auth) verify(pass string) bool {
	if a.cfg.PasswordHash != "" {
		return bcrypt.CompareHashAndPassword([]byte(a.cfg.PasswordHash), []byte(pass)) == nil
	}
	return subtle.ConstantTimeCompare([]byte(pass), []byte(a.cfg.Password)) == 1
}

func (a *Auth) valid(tok string) bool {
	a.mu.Lock()
	defer a.mu.Unlock()
	exp, ok := a.tokens[tok]
	if !ok {
		return false
	}
	if time.Now().After(exp) {
		delete(a.tokens, tok)
		return false
	}
	return true
}

func (a *Auth) revoke(tok string) {
	a.mu.Lock()
	delete(a.tokens, tok)
	a.mu.Unlock()
}

func (a *Auth) middleware(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		c, err := r.Cookie(sessionCookie)
		if err != nil || !a.valid(c.Value) {
			if isAPI(r) {
				http.Error(w, `{"error":"unauthorized"}`, http.StatusUnauthorized)
			} else {
				http.Redirect(w, r, "/login", http.StatusFound)
			}
			return
		}
		next(w, r)
	}
}

func isAPI(r *http.Request) bool {
	return len(r.URL.Path) >= 4 && r.URL.Path[:4] == "/api"
}

// ---------- Hub (SSE) ----------

type Hub struct {
	mu   sync.RWMutex
	subs map[chan string]struct{}
}

func newHub() *Hub { return &Hub{subs: map[chan string]struct{}{}} }

func (h *Hub) run() {} // 占位，保留扩展

func (h *Hub) subscribe() chan string {
	ch := make(chan string, 64)
	h.mu.Lock()
	h.subs[ch] = struct{}{}
	h.mu.Unlock()
	return ch
}

func (h *Hub) unsubscribe(ch chan string) {
	h.mu.Lock()
	delete(h.subs, ch)
	close(ch)
	h.mu.Unlock()
}

func (h *Hub) broadcast(msg string) {
	h.mu.RLock()
	defer h.mu.RUnlock()
	for ch := range h.subs {
		select {
		case ch <- msg:
		default: // 慢客户端丢弃，避免阻塞
		}
	}
}

// ---------- helpers ----------

func writeJSON(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	_ = json.NewEncoder(w).Encode(v)
}

func writeErr(w http.ResponseWriter, code int, msg string) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(code)
	fmt.Fprintf(w, `{"error":%q}`, msg)
}
