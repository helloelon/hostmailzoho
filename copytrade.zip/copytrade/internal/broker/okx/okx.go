package okx

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"

	"github.com/domigo/copytrade/internal/broker"
	"github.com/domigo/copytrade/internal/config"
	"github.com/domigo/copytrade/internal/model"
)

type Client struct {
	name       string
	baseURL    string
	key        string
	secret     string
	passphrase string
	mgnMode    string
	demo       bool
	hc         *http.Client
	infoMu     sync.RWMutex
	symbolMap  map[string]*model.SymbolInfo
}

func New(cfg config.Exchange) (*Client, error) {
	mgn := cfg.MarginMode
	if mgn != "isolated" {
		mgn = "cross"
	}
	hc := &http.Client{Timeout: 15 * time.Second}
	if cfg.Proxy != "" {
		p, err := url.Parse(cfg.Proxy)
		if err != nil {
			return nil, fmt.Errorf("okx proxy parse: %w", err)
		}
		hc.Transport = &http.Transport{Proxy: http.ProxyURL(p)}
	}
	c := &Client{
		name: cfg.Name, baseURL: "https://www.okx.com", key: cfg.APIKey,
		secret: cfg.APISecret, passphrase: cfg.Passphrase, mgnMode: mgn,
		demo: cfg.Testnet, hc: hc, symbolMap: map[string]*model.SymbolInfo{},
	}
	if err := c.ensureHedgeMode(); err != nil {
		log.Printf("[okx:%s] ensure hedge mode: %v (若已是双向可忽略)", cfg.Name, err)
	}
	if err := c.refreshSymbolInfo(); err != nil {
		return nil, fmt.Errorf("okx load instruments: %w", err)
	}
	return c, nil
}

func (c *Client) Name() string { return c.name }
func (c *Client) Type() string { return "okx" }

// ---------- 签名与请求 ----------

func (c *Client) sign(ts, method, requestPath, body string) string {
	s := ts + method + requestPath + body
	mac := hmac.New(sha256.New, []byte(c.secret))
	mac.Write([]byte(s))
	return base64.StdEncoding.EncodeToString(mac.Sum(nil))
}

func tsISO() string {
	return time.Now().UTC().Format("2006-01-02T15:04:05.000Z")
}

type wrapper struct {
	Code string          `json:"code"`
	Msg  string          `json:"msg"`
	Data json.RawMessage `json:"data"`
}

// call 发起请求并返回 data 字段原始 JSON
func (c *Client) call(ctx context.Context, method, path string, query url.Values, body any, signed bool) (json.RawMessage, error) {
	var bodyStr string
	if body != nil {
		b, err := json.Marshal(body)
		if err != nil {
			return nil, err
		}
		bodyStr = string(b)
	}
	reqPath := path
	if query != nil && len(query) > 0 {
		reqPath = path + "?" + query.Encode()
	}
	reqURL := c.baseURL + reqPath

	var req *http.Request
	var err error
	if bodyStr != "" {
		req, err = http.NewRequestWithContext(ctx, method, reqURL, strings.NewReader(bodyStr))
	} else {
		req, err = http.NewRequestWithContext(ctx, method, reqURL, nil)
	}
	if err != nil {
		return nil, err
	}
	if bodyStr != "" {
		req.Header.Set("Content-Type", "application/json")
	}
	if c.demo {
		req.Header.Set("x-simulated-trading", "1")
	}
	if signed {
		ts := tsISO()
		req.Header.Set("OK-ACCESS-KEY", c.key)
		req.Header.Set("OK-ACCESS-SIGN", c.sign(ts, method, reqPath, bodyStr))
		req.Header.Set("OK-ACCESS-TIMESTAMP", ts)
		req.Header.Set("OK-ACCESS-PASSPHRASE", c.passphrase)
	}

	resp, err := c.hc.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(resp.Body)
	if resp.StatusCode >= 400 {
		return nil, fmt.Errorf("okx %s %s -> %d: %s", method, reqPath, resp.StatusCode, string(raw))
	}
	var w wrapper
	if err := json.Unmarshal(raw, &w); err != nil {
		return nil, fmt.Errorf("okx decode: %w; body=%s", err, string(raw))
	}
	if w.Code != "0" {
		return nil, fmt.Errorf("okx %s %s code=%s msg=%s", method, reqPath, w.Code, w.Msg)
	}
	return w.Data, nil
}

// ---------- 持仓模式 / 杠杆 ----------

func (c *Client) ensureHedgeMode() error {
	_, err := c.call(context.Background(), http.MethodPost, "/api/v5/account/set-position-mode",
		nil, map[string]string{"posMode": "long_short_mode"}, true)
	return err
}

func (c *Client) SetLeverage(ctx context.Context, symbol string, leverage int) error {
	_, err := c.call(ctx, http.MethodPost, "/api/v5/account/set-leverage", nil,
		map[string]any{"instId": symbol, "lever": fmt.Sprintf("%d", leverage), "mgnMode": c.mgnMode}, true)
	return err
}

// ---------- 精度 ----------

func (c *Client) refreshSymbolInfo() error {
	q := url.Values{}
	q.Set("instType", "SWAP")
	data, err := c.call(context.Background(), http.MethodGet, "/api/v5/public/instruments", q, nil, false)
	if err != nil {
		return err
	}
	var arr []struct {
		InstID string `json:"instId"`
		CtVal  string `json:"ctVal"`
		LotSz  string `json:"lotSz"`
		TickSz string `json:"tickSz"`
		MinSz  string `json:"minSz"`
	}
	if err := json.Unmarshal(data, &arr); err != nil {
		return err
	}
	m := map[string]*model.SymbolInfo{}
	for _, s := range arr {
		m[s.InstID] = &model.SymbolInfo{
			Symbol: s.InstID, TickSize: s.TickSz, LotSz: s.LotSz, MinQty: s.MinSz, CtVal: s.CtVal,
		}
	}
	c.infoMu.Lock()
	c.symbolMap = m
	c.infoMu.Unlock()
	return nil
}

func (c *Client) SymbolInfo(ctx context.Context, symbol string) (*model.SymbolInfo, error) {
	c.infoMu.RLock()
	info, ok := c.symbolMap[symbol]
	c.infoMu.RUnlock()
	if ok {
		return info, nil
	}
	if err := c.refreshSymbolInfo(); err != nil {
		return nil, err
	}
	c.infoMu.RLock()
	info, ok = c.symbolMap[symbol]
	c.infoMu.RUnlock()
	if !ok {
		return nil, fmt.Errorf("okx instId not found: %s", symbol)
	}
	return info, nil
}

func (c *Client) LastPrice(ctx context.Context, symbol string) (string, error) {
	q := url.Values{}
	q.Set("instId", symbol)
	data, err := c.call(ctx, http.MethodGet, "/api/v5/market/ticker", q, nil, false)
	if err != nil {
		return "", err
	}
	var arr []struct {
		Last string `json:"last"`
	}
	if err := json.Unmarshal(data, &arr); err != nil || len(arr) == 0 {
		return "", fmt.Errorf("okx ticker empty: %s", symbol)
	}
	return arr[0].Last, nil
}

// ---------- 下单 / 撤单 / 查单 ----------

func (c *Client) PlaceOrder(ctx context.Context, req model.OrderReq) (*model.OrderResp, error) {
	body := map[string]any{
		"instId":   req.Symbol,
		"tdMode":   c.mgnMode,
		"side":     strings.ToLower(req.Side),
		"posSide":  strings.ToLower(req.PositionSide),
		"ordType":  strings.ToLower(req.Type),
		"sz":       req.Quantity,
	}
	if req.Type == "LIMIT" {
		body["px"] = req.Price
	}
	if req.ReduceOnly {
		body["reduceOnly"] = true
	}
	if req.ClientOrderID != "" {
		body["clOrdId"] = req.ClientOrderID
	}
	data, err := c.call(ctx, http.MethodPost, "/api/v5/trade/order", nil, body, true)
	if err != nil {
		return nil, err
	}
	var arr []struct {
		OrdID   string `json:"ordId"`
		ClOrdID string `json:"clOrdId"`
		SCode   string `json:"sCode"`
		SMsg    string `json:"sMsg"`
	}
	if err := json.Unmarshal(data, &arr); err != nil || len(arr) == 0 {
		return nil, fmt.Errorf("okx place order decode empty")
	}
	if arr[0].SCode != "0" {
		return nil, fmt.Errorf("okx place order sCode=%s sMsg=%s", arr[0].SCode, arr[0].SMsg)
	}
	return &model.OrderResp{
		Exchange: c.name, Symbol: req.Symbol, OrderID: arr[0].OrdID,
		ClientOrderID: arr[0].ClOrdID, Status: "NEW", Msg: arr[0].SMsg,
	}, nil
}

func (c *Client) CancelOrder(ctx context.Context, symbol, orderID string) (*model.OrderResp, error) {
	body := map[string]string{"instId": symbol}
	if looksLikeClOrdID(orderID) {
		body["clOrdId"] = orderID
	} else {
		body["ordId"] = orderID
	}
	data, err := c.call(ctx, http.MethodPost, "/api/v5/trade/cancel-order", nil, body, true)
	if err != nil {
		return nil, err
	}
	var arr []struct {
		OrdID string `json:"ordId"`
		SCode string `json:"sCode"`
		SMsg  string `json:"sMsg"`
	}
	if err := json.Unmarshal(data, &arr); err != nil || len(arr) == 0 {
		return nil, fmt.Errorf("okx cancel decode empty")
	}
	if arr[0].SCode != "0" {
		return nil, fmt.Errorf("okx cancel sCode=%s sMsg=%s", arr[0].SCode, arr[0].SMsg)
	}
	return &model.OrderResp{Exchange: c.name, Symbol: symbol, OrderID: arr[0].OrdID, Status: "CANCELED"}, nil
}

func (c *Client) GetOrder(ctx context.Context, symbol, orderID string) (*model.OrderResp, error) {
	q := url.Values{}
	q.Set("instId", symbol)
	if looksLikeClOrdID(orderID) {
		q.Set("clOrdId", orderID)
	} else {
		q.Set("ordId", orderID)
	}
	data, err := c.call(ctx, http.MethodGet, "/api/v5/trade/order", q, nil, true)
	if err != nil {
		return nil, err
	}
	var arr []struct {
		OrdID string `json:"ordId"`
		State string `json:"state"`
	}
	if err := json.Unmarshal(data, &arr); err != nil || len(arr) == 0 {
		return nil, fmt.Errorf("okx get order decode empty")
	}
	return &model.OrderResp{Exchange: c.name, Symbol: symbol, OrderID: arr[0].OrdID, Status: arr[0].State}, nil
}

func looksLikeClOrdID(id string) bool {
	// OKX ordId 为纯数字，clOrdId 含字母则按 clOrdId 处理
	for _, r := range id {
		if r < '0' || r > '9' {
			return true
		}
	}
	return false
}

// ---------- 持仓 / 挂单 ----------

func (c *Client) GetPositions(ctx context.Context) ([]model.Position, error) {
	q := url.Values{}
	q.Set("instType", "SWAP")
	data, err := c.call(ctx, http.MethodGet, "/api/v5/account/positions", q, nil, true)
	if err != nil {
		return nil, err
	}
	var arr []struct {
		InstID   string `json:"instId"`
		PosSide  string `json:"posSide"`
		Pos      string `json:"pos"`
		AvgPx    string `json:"avgPx"`
		MarkPx   string `json:"markPx"`
		Upl      string `json:"upl"`
		Lever    string `json:"lever"`
	}
	if err := json.Unmarshal(data, &arr); err != nil {
		return nil, err
	}
	out := make([]model.Position, 0, len(arr))
	for _, p := range arr {
		pos := strings.TrimLeft(p.Pos, "-")
		if pos == "0" || pos == "0.0" || pos == "" {
			continue
		}
		lev := 0
		if p.Lever != "" {
			fmt.Sscanf(p.Lever, "%d", &lev)
		}
		out = append(out, model.Position{
			Exchange: c.name, Symbol: p.InstID,
			PositionSide: strings.ToUpper(p.PosSide), Quantity: pos,
			EntryPrice: p.AvgPx, MarkPrice: p.MarkPx, UnrealizedPnl: p.Upl,
			Leverage: lev, MarginType: c.mgnMode,
		})
	}
	return out, nil
}

func (c *Client) GetOpenOrders(ctx context.Context) ([]model.OpenOrder, error) {
	q := url.Values{}
	q.Set("instType", "SWAP")
	data, err := c.call(ctx, http.MethodGet, "/api/v5/trade/orders-pending", q, nil, true)
	if err != nil {
		return nil, err
	}
	var arr []struct {
		InstID     string `json:"instId"`
		OrdID      string `json:"ordId"`
		ClOrdID    string `json:"clOrdId"`
		Side       string `json:"side"`
		PosSide    string `json:"posSide"`
		OrdType    string `json:"ordType"`
		Sz         string `json:"sz"`
		Px         string `json:"px"`
		ReduceOnly bool   `json:"reduceOnly"`
		State      string `json:"state"`
		CTime      string `json:"cTime"`
	}
	if err := json.Unmarshal(data, &arr); err != nil {
		return nil, err
	}
	out := make([]model.OpenOrder, 0, len(arr))
	for _, o := range arr {
		t := int64(0)
		if o.CTime != "" {
			fmt.Sscanf(o.CTime, "%d", &t)
		}
		out = append(out, model.OpenOrder{
			Exchange: c.name, Symbol: o.InstID, OrderID: o.OrdID, ClientOrderID: o.ClOrdID,
			Side: strings.ToUpper(o.Side), PositionSide: strings.ToUpper(o.PosSide),
			Type: strings.ToUpper(o.OrdType), Quantity: o.Sz, Price: o.Px,
			ReduceOnly: o.ReduceOnly, Status: o.State, Time: t,
		})
	}
	return out, nil
}

// ClosePosition 全平指定方向持仓：reduceOnly 市价单
func (c *Client) ClosePosition(ctx context.Context, symbol, positionSide string) (*model.OrderResp, error) {
	positions, err := c.GetPositions(ctx)
	if err != nil {
		return nil, err
	}
	var sz string
	for _, p := range positions {
		if p.Symbol == symbol && strings.EqualFold(p.PositionSide, positionSide) {
			sz = p.Quantity
			break
		}
	}
	if sz == "" {
		return nil, fmt.Errorf("no %s position on %s to close", positionSide, symbol)
	}
	dir := broker.DirLong
	if strings.EqualFold(positionSide, "SHORT") {
		dir = broker.DirShort
	}
	side, ps := broker.HedgeParams(broker.ActClose, dir)
	return c.PlaceOrder(ctx, model.OrderReq{
		Symbol: symbol, Side: side, PositionSide: ps, Type: "MARKET",
		Quantity: sz, ReduceOnly: true,
	})
}
