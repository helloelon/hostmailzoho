package binance

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/domigo/copytrade/internal/broker"
	"github.com/domigo/copytrade/internal/config"
	"github.com/domigo/copytrade/internal/model"
)

type Client struct {
	name      string
	baseURL   string
	key       string
	secret    string
	hc        *http.Client
	timeOff   int64 // ms, serverTime - localTime
	timeMu    sync.Mutex
	infoMu    sync.RWMutex
	symbolMap map[string]*model.SymbolInfo
}

func New(cfg config.Exchange) (*Client, error) {
	base := "https://fapi.binance.com"
	if cfg.Testnet {
		base = "https://testnet.binancefuture.com"
	}
	hc := &http.Client{Timeout: 15 * time.Second}
	if cfg.Proxy != "" {
		p, err := url.Parse(cfg.Proxy)
		if err != nil {
			return nil, fmt.Errorf("binance proxy parse: %w", err)
		}
		hc.Transport = &http.Transport{Proxy: http.ProxyURL(p)}
	}
	c := &Client{name: cfg.Name, baseURL: base, key: cfg.APIKey, secret: cfg.APISecret, hc: hc, symbolMap: map[string]*model.SymbolInfo{}}
	if err := c.syncTime(); err != nil {
		return nil, fmt.Errorf("binance sync time: %w", err)
	}
	if err := c.ensureHedgeMode(); err != nil {
		// 已为双向持仓会返回 -4059，忽略即可
		log.Printf("[binance:%s] ensure hedge mode: %v (若已是双向可忽略)", cfg.Name, err)
	}
	if err := c.refreshSymbolInfo(); err != nil {
		return nil, fmt.Errorf("binance load exchangeInfo: %w", err)
	}
	return c, nil
}

func (c *Client) Name() string { return c.name }
func (c *Client) Type() string { return "binance" }

// ---------- 签名与请求 ----------

func (c *Client) sign(qs string) string {
	mac := hmac.New(sha256.New, []byte(c.secret))
	mac.Write([]byte(qs))
	return hex.EncodeToString(mac.Sum(nil))
}

func (c *Client) syncTime() error {
	var resp struct {
		ServerTime int64 `json:"serverTime"`
	}
	if err := c.do(context.Background(), http.MethodGet, "/fapi/v1/time", nil, false, &resp); err != nil {
		return err
	}
	c.timeMu.Lock()
	c.timeOff = resp.ServerTime - time.Now().UnixMilli()
	c.timeMu.Unlock()
	return nil
}

func (c *Client) timestamp() int64 {
	c.timeMu.Lock()
	defer c.timeMu.Unlock()
	return time.Now().UnixMilli() + c.timeOff
}

type apiErr struct {
	Code int    `json:"code"`
	Msg  string `json:"msg"`
}

func (e *apiErr) Error() string { return fmt.Sprintf("binance %d: %s", e.Code, e.Msg) }

func (c *Client) do(ctx context.Context, method, path string, params url.Values, signed bool, out any) error {
	if params == nil {
		params = url.Values{}
	}
	if signed {
		params.Set("timestamp", strconv.FormatInt(c.timestamp(), 10))
		params.Set("recvWindow", "10000")
	}
	qs := params.Encode()
	if signed {
		qs = qs + "&signature=" + c.sign(qs)
	}

	reqURL := c.baseURL + path
	var body io.Reader
	if method == http.MethodGet || method == http.MethodDelete {
		if qs != "" {
			reqURL += "?" + qs
		}
	} else {
		body = strings.NewReader(qs)
	}

	req, err := http.NewRequestWithContext(ctx, method, reqURL, body)
	if err != nil {
		return err
	}
	req.Header.Set("X-MBX-APIKEY", c.key)
	if method != http.MethodGet && method != http.MethodDelete {
		req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	}

	resp, err := c.hc.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(resp.Body)

	// 时间偏移错误：重同步后重试一次
	if resp.StatusCode >= 400 {
		var ae apiErr
		_ = json.Unmarshal(raw, &ae)
		if ae.Code == -1021 || ae.Code == -1022 {
			if e := c.syncTime(); e == nil {
				return c.doNoRetry(ctx, method, path, params, signed, out)
			}
		}
		return fmt.Errorf("binance %s %s -> %d: %s", method, path, resp.StatusCode, string(raw))
	}
	if out != nil {
		return json.Unmarshal(raw, out)
	}
	return nil
}

// doNoRetry 同 do 但不再触发时间重试，避免死循环
func (c *Client) doNoRetry(ctx context.Context, method, path string, params url.Values, signed bool, out any) error {
	if params == nil {
		params = url.Values{}
	}
	if signed {
		params.Set("timestamp", strconv.FormatInt(c.timestamp(), 10))
		params.Set("recvWindow", "10000")
	}
	qs := params.Encode()
	if signed {
		qs = qs + "&signature=" + c.sign(qs)
	}
	reqURL := c.baseURL + path
	var body io.Reader
	if method == http.MethodGet || method == http.MethodDelete {
		if qs != "" {
			reqURL += "?" + qs
		}
	} else {
		body = strings.NewReader(qs)
	}
	req, err := http.NewRequestWithContext(ctx, method, reqURL, body)
	if err != nil {
		return err
	}
	req.Header.Set("X-MBX-APIKEY", c.key)
	if method != http.MethodGet && method != http.MethodDelete {
		req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	}
	resp, err := c.hc.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(resp.Body)
	if resp.StatusCode >= 400 {
		return fmt.Errorf("binance %s %s -> %d: %s", method, path, resp.StatusCode, string(raw))
	}
	if out != nil {
		return json.Unmarshal(raw, out)
	}
	return nil
}

// ---------- 持仓模式 / 杠杆 ----------

func (c *Client) ensureHedgeMode() error {
	p := url.Values{}
	p.Set("dualSidePosition", "true")
	return c.do(context.Background(), http.MethodPost, "/fapi/v1/positionSide/dual", p, true, nil)
}

func (c *Client) SetLeverage(ctx context.Context, symbol string, leverage int) error {
	p := url.Values{}
	p.Set("symbol", symbol)
	p.Set("leverage", strconv.Itoa(leverage))
	return c.do(ctx, http.MethodPost, "/fapi/v1/leverage", p, true, nil)
}

// ---------- 精度 ----------

func (c *Client) refreshSymbolInfo() error {
	var resp struct {
		Symbols []struct {
			Symbol  string `json:"symbol"`
			Filters []struct {
				FilterType string `json:"filterType"`
				TickSize   string `json:"tickSize"`
				StepSize   string `json:"stepSize"`
				MinQty     string `json:"minQty"`
				MinNotional string `json:"minNotional"`
			} `json:"filters"`
		} `json:"symbols"`
	}
	if err := c.do(context.Background(), http.MethodGet, "/fapi/v1/exchangeInfo", nil, false, &resp); err != nil {
		return err
	}
	m := map[string]*model.SymbolInfo{}
	for _, s := range resp.Symbols {
		info := &model.SymbolInfo{Symbol: s.Symbol}
		for _, f := range s.Filters {
			switch f.FilterType {
			case "PRICE_FILTER":
				info.TickSize = f.TickSize
			case "LOT_SIZE":
				info.StepSize = f.StepSize
				info.MinQty = f.MinQty
			case "MIN_NOTIONAL":
				info.MinNotional = f.MinNotional
			}
		}
		m[s.Symbol] = info
	}
	c.infoMu.Lock()
	c.symbolMap = m
	c.infoMu.Unlock()
	return nil
}

func (c *Client) SymbolInfo(ctx context.Context, symbol string) (*model.SymbolInfo, error) {
	c.infoMu.RLock()
	info, ok := c.symbolMap[symbol]
	c.infoMu.RUnlock()
	if ok {
		return info, nil
	}
	// 缓存未命中，刷新一次
	if err := c.refreshSymbolInfo(); err != nil {
		return nil, err
	}
	c.infoMu.RLock()
	info, ok = c.symbolMap[symbol]
	c.infoMu.RUnlock()
	if !ok {
		return nil, fmt.Errorf("binance symbol not found: %s", symbol)
	}
	return info, nil
}

func (c *Client) LastPrice(ctx context.Context, symbol string) (string, error) {
	p := url.Values{}
	p.Set("symbol", symbol)
	var resp struct {
		Price string `json:"price"`
	}
	if err := c.do(ctx, http.MethodGet, "/fapi/v1/ticker/price", p, false, &resp); err != nil {
		return "", err
	}
	return resp.Price, nil
}

// ---------- 下单 / 撤单 / 查单 ----------

func (c *Client) PlaceOrder(ctx context.Context, req model.OrderReq) (*model.OrderResp, error) {
	p := url.Values{}
	p.Set("symbol", req.Symbol)
	p.Set("side", req.Side)
	p.Set("positionSide", req.PositionSide)
	p.Set("type", req.Type)
	p.Set("quantity", req.Quantity)
	if req.Type == "LIMIT" {
		p.Set("timeInForce", "GTC")
		p.Set("price", req.Price)
	}
	if req.ReduceOnly {
		p.Set("reduceOnly", "true")
	}
	if req.ClientOrderID != "" {
		p.Set("newClientOrderId", req.ClientOrderID)
	}
	var resp struct {
		OrderID       int64  `json:"orderId"`
		ClientOrderID string `json:"clientOrderId"`
		Status        string `json:"status"`
	}
	if err := c.do(ctx, http.MethodPost, "/fapi/v1/order", p, true, &resp); err != nil {
		return nil, err
	}
	return &model.OrderResp{
		Exchange: c.name, Symbol: req.Symbol,
		OrderID: strconv.FormatInt(resp.OrderID, 10),
		ClientOrderID: resp.ClientOrderID, Status: resp.Status,
	}, nil
}

func (c *Client) CancelOrder(ctx context.Context, symbol, orderID string) (*model.OrderResp, error) {
	p := url.Values{}
	p.Set("symbol", symbol)
	if _, err := strconv.ParseInt(orderID, 10, 64); err == nil {
		p.Set("orderId", orderID)
	} else {
		p.Set("origClientOrderId", orderID)
	}
	var resp struct {
		OrderID       int64  `json:"orderId"`
		ClientOrderID string `json:"clientOrderId"`
		Status        string `json:"status"`
	}
	if err := c.do(ctx, http.MethodDelete, "/fapi/v1/order", p, true, &resp); err != nil {
		return nil, err
	}
	return &model.OrderResp{Exchange: c.name, Symbol: symbol, OrderID: strconv.FormatInt(resp.OrderID, 10), ClientOrderID: resp.ClientOrderID, Status: resp.Status}, nil
}

func (c *Client) GetOrder(ctx context.Context, symbol, orderID string) (*model.OrderResp, error) {
	p := url.Values{}
	p.Set("symbol", symbol)
	if _, err := strconv.ParseInt(orderID, 10, 64); err == nil {
		p.Set("orderId", orderID)
	} else {
		p.Set("origClientOrderId", orderID)
	}
	var resp struct {
		OrderID       int64  `json:"orderId"`
		ClientOrderID string `json:"clientOrderId"`
		Status        string `json:"status"`
	}
	if err := c.do(ctx, http.MethodGet, "/fapi/v1/order", p, true, &resp); err != nil {
		return nil, err
	}
	return &model.OrderResp{Exchange: c.name, Symbol: symbol, OrderID: strconv.FormatInt(resp.OrderID, 10), ClientOrderID: resp.ClientOrderID, Status: resp.Status}, nil
}

// ---------- 持仓 / 挂单 ----------

func (c *Client) GetPositions(ctx context.Context) ([]model.Position, error) {
	var arr []struct {
		Symbol         string `json:"symbol"`
		PositionSide   string `json:"positionSide"`
		PositionAmt    string `json:"positionAmt"`
		EntryPrice     string `json:"entryPrice"`
		MarkPrice      string `json:"markPrice"`
		UnRealizedProfit string `json:"unRealizedProfit"`
		Leverage       int    `json:"leverage"`
	}
	if err := c.do(ctx, http.MethodGet, "/fapi/v2/positionRisk", nil, true, &arr); err != nil {
		return nil, err
	}
	out := make([]model.Position, 0, len(arr))
	for _, p := range arr {
		amt := strings.TrimLeft(p.PositionAmt, "-")
		if amt == "0" || amt == "0.0" || amt == "" {
			continue
		}
		out = append(out, model.Position{
			Exchange: c.name, Symbol: p.Symbol, PositionSide: p.PositionSide,
			Quantity: amt, EntryPrice: p.EntryPrice, MarkPrice: p.MarkPrice,
			UnrealizedPnl: p.UnRealizedProfit, Leverage: p.Leverage,
		})
	}
	return out, nil
}

func (c *Client) GetOpenOrders(ctx context.Context) ([]model.OpenOrder, error) {
	var arr []struct {
		Symbol        string `json:"symbol"`
		OrderID       int64  `json:"orderId"`
		ClientOrderID string `json:"clientOrderId"`
		Side          string `json:"side"`
		PositionSide  string `json:"positionSide"`
		Type          string `json:"type"`
		OrigQty       string `json:"origQty"`
		Price         string `json:"price"`
		ReduceOnly    bool   `json:"reduceOnly"`
		Status        string `json:"status"`
		Time          int64  `json:"time"`
	}
	if err := c.do(ctx, http.MethodGet, "/fapi/v1/openOrders", nil, true, &arr); err != nil {
		return nil, err
	}
	out := make([]model.OpenOrder, 0, len(arr))
	for _, o := range arr {
		out = append(out, model.OpenOrder{
			Exchange: c.name, Symbol: o.Symbol, OrderID: strconv.FormatInt(o.OrderID, 10),
			ClientOrderID: o.ClientOrderID, Side: o.Side, PositionSide: o.PositionSide,
			Type: o.Type, Quantity: o.OrigQty, Price: o.Price, ReduceOnly: o.ReduceOnly,
			Status: o.Status, Time: o.Time,
		})
	}
	return out, nil
}

// ClosePosition 全平指定方向持仓：reduceOnly 市价单
func (c *Client) ClosePosition(ctx context.Context, symbol, positionSide string) (*model.OrderResp, error) {
	positions, err := c.GetPositions(ctx)
	if err != nil {
		return nil, err
	}
	var qty string
	for _, p := range positions {
		if p.Symbol == symbol && strings.EqualFold(p.PositionSide, positionSide) {
			qty = p.Quantity
			break
		}
	}
	if qty == "" {
		return nil, fmt.Errorf("no %s position on %s to close", positionSide, symbol)
	}
	action := broker.ActClose
	dir := broker.DirLong
	if strings.EqualFold(positionSide, "SHORT") {
		dir = broker.DirShort
	}
	side, ps := broker.HedgeParams(action, dir)
	return c.PlaceOrder(ctx, model.OrderReq{
		Symbol: symbol, Side: side, PositionSide: ps, Type: "MARKET",
		Quantity: qty, ReduceOnly: true,
	})
}
