package broker

import (
	"fmt"

	"github.com/domigo/copytrade/internal/model"
	"github.com/shopspring/decimal"
)

// ComputeOpenQty 由固定保证金换算开仓数量（单一数据源）：
//
//	notion = marginUSDT * leverage
//	每张/每单位名义价值 = price                      （币安，ctVal 视为 1）
//	                     = ctVal * price            （OKX 合约面值）
//	rawQty = notion / unitValue
//	最终按 step 向下取整，并校验 >= minQty
func ComputeOpenQty(marginUSDT string, leverage int, price string, info *model.SymbolInfo) (string, error) {
	margin, err := decimal.NewFromString(marginUSDT)
	if err != nil {
		return "", fmt.Errorf("margin 解析失败: %w", err)
	}
	px, err := decimal.NewFromString(price)
	if err != nil {
		return "", fmt.Errorf("price 解析失败: %w", err)
	}
	if px.IsZero() || px.IsNegative() {
		return "", fmt.Errorf("价格无效: %s", price)
	}
	notion := margin.Mul(decimal.NewFromInt(int64(leverage)))

	unit := px
	if info.CtVal != "" {
		ctVal, err := decimal.NewFromString(info.CtVal)
		if err != nil {
			return "", fmt.Errorf("ctVal 解析失败: %w", err)
		}
		if !ctVal.IsZero() {
			unit = ctVal.Mul(px)
		}
	}
	raw := notion.Div(unit)
	return FormatQty(raw.String(), SymbolStep(info), SymbolMinQty(info))
}
