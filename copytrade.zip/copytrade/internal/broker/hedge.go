package broker

import (
	"fmt"
	"strings"

	"github.com/domigo/copytrade/internal/model"
	"github.com/shopspring/decimal"
)

type Action string    // OPEN / CLOSE
type Direction string // LONG / SHORT

const (
	ActOpen  Action = "OPEN"
	ActClose Action = "CLOSE"
	DirLong  Direction = "LONG"
	DirShort Direction = "SHORT"
)

// 单一数据源：双向持仓模式下，由 动作+方向 生成 side 与 positionSide
// 开多=BUY/LONG，开空=SELL/SHORT，平多=SELL/LONG，平空=BUY/SHORT
func HedgeParams(action Action, dir Direction) (side, positionSide string) {
	switch {
	case action == ActOpen && dir == DirLong:
		return "BUY", "LONG"
	case action == ActOpen && dir == DirShort:
		return "SELL", "SHORT"
	case action == ActClose && dir == DirLong:
		return "SELL", "LONG"
	case action == ActClose && dir == DirShort:
		return "BUY", "SHORT"
	}
	return "", ""
}

// 从带单者成交的 side + positionSide 反推动作与方向
func InferLeaderAction(side, positionSide string) (Action, Direction) {
	s := strings.ToUpper(side)
	p := strings.ToUpper(positionSide)
	switch {
	case s == "BUY" && p == "LONG":
		return ActOpen, DirLong
	case s == "SELL" && p == "SHORT":
		return ActOpen, DirShort
	case s == "SELL" && p == "LONG":
		return ActClose, DirLong
	case s == "BUY" && p == "SHORT":
		return ActClose, DirShort
	}
	if p == "" || p == "BOTH" {
		if s == "BUY" {
			return ActOpen, DirLong
		}
		return ActOpen, DirShort
	}
	return ActOpen, DirLong
}

func decimalsOf(s string) int32 {
	i := strings.IndexByte(s, '.')
	if i < 0 {
		return 0
	}
	return int32(len(s) - i - 1)
}

// RoundDown 把 value 向下取整到 step 的整数倍，返回与 step 小数位对齐的字符串
func RoundDown(value, step string) (string, error) {
	v, err := decimal.NewFromString(value)
	if err != nil {
		return "", err
	}
	st, err := decimal.NewFromString(step)
	if err != nil {
		return "", err
	}
	if st.IsZero() {
		return v.String(), nil
	}
	out := v.Div(st).Floor().Mul(st)
	return out.StringFixed(decimalsOf(step)), nil
}

// FormatQty 按 step 向下取整数量；若结果 < minQty 返回错误
func FormatQty(qty, step, minQty string) (string, error) {
	out, err := RoundDown(qty, step)
	if err != nil {
		return "", err
	}
	if minQty != "" {
		o, _ := decimal.NewFromString(out)
		mn, err := decimal.NewFromString(minQty)
		if err == nil && o.LessThan(mn) {
			return "", fmt.Errorf("数量 %s 小于最小下单量 %s", out, minQty)
		}
	}
	return out, nil
}

// FormatPrice 按 tickSize 向下取整价格
func FormatPrice(price, tickSize string) (string, error) {
	return RoundDown(price, tickSize)
}

// SymbolStep 返回交易对生效的数量步进
func SymbolStep(info *model.SymbolInfo) string {
	if info.StepSize != "" {
		return info.StepSize
	}
	return info.LotSz
}

// SymbolMinQty 返回交易对最小数量
func SymbolMinQty(info *model.SymbolInfo) string {
	if info.MinQty != "" {
		return info.MinQty
	}
	return info.LotSz
}
