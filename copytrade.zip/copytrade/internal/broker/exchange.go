package broker

import (
	"context"

	"github.com/domigo/copytrade/internal/model"
)

// 交易所统一抽象：开仓/平仓/撤单/查单 + UI 只读 + 杠杆与精度
type Exchange interface {
	Name() string
	Type() string // binance / okx

	// 下单（开仓或平仓由 req.ReduceOnly 决定）
	PlaceOrder(ctx context.Context, req model.OrderReq) (*model.OrderResp, error)
	// 全平指定 symbol+方向 的持仓（reduceOnly 市价）
	ClosePosition(ctx context.Context, symbol, positionSide string) (*model.OrderResp, error)
	// 撤单
	CancelOrder(ctx context.Context, symbol, orderID string) (*model.OrderResp, error)
	// 查单
	GetOrder(ctx context.Context, symbol, orderID string) (*model.OrderResp, error)

	// 只读（UI / 风控）
	GetPositions(ctx context.Context) ([]model.Position, error)
	GetOpenOrders(ctx context.Context) ([]model.OpenOrder, error)

	// 下单前置：设杠杆、取精度、取最新价
	SetLeverage(ctx context.Context, symbol string, leverage int) error
	SymbolInfo(ctx context.Context, symbol string) (*model.SymbolInfo, error)
	LastPrice(ctx context.Context, symbol string) (string, error)
}
