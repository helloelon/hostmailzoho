package copy

import (
	"context"
	"fmt"
	"log"
	"sort"
	"strconv"
	"sync"
	"time"

	"github.com/domigo/copytrade/internal/broker"
	"github.com/domigo/copytrade/internal/config"
	"github.com/domigo/copytrade/internal/leader"
	"github.com/domigo/copytrade/internal/model"
	"github.com/domigo/copytrade/internal/notify"
	"github.com/domigo/copytrade/internal/store"
	"github.com/shopspring/decimal"
)

// Sink 用于把引擎事件推送给上层（如 SSE），避免引擎依赖 server
type Sink func(kind string, payload any)

// Runtime 可在运行时通过管理页修改的跟单参数
type Runtime struct {
	mu         sync.RWMutex
	Enabled    bool
	MarginUSDT float64
	Leverage   int
	OrderType  string // limit / market
}

func NewRuntime(c config.Copy) *Runtime {
	return &Runtime{Enabled: c.Enabled, MarginUSDT: c.MarginUSDT, Leverage: c.Leverage, OrderType: c.OrderType}
}

func (r *Runtime) Snapshot() (enabled bool, margin string, leverage int, orderType string) {
	r.mu.RLock()
	defer r.mu.RUnlock()
	return r.Enabled, decimal.NewFromFloat(r.MarginUSDT).String(), r.Leverage, r.OrderType
}

func (r *Runtime) Update(enabled bool, margin float64, leverage int, orderType string) error {
	if margin <= 0 {
		return fmt.Errorf("margin 必须 > 0")
	}
	if leverage <= 0 {
		return fmt.Errorf("leverage 必须 > 0")
	}
	if orderType != "limit" && orderType != "market" {
		return fmt.Errorf("order_type 只能是 limit 或 market")
	}
	r.mu.Lock()
	r.Enabled, r.MarginUSDT, r.Leverage, r.OrderType = enabled, margin, leverage, orderType
	r.mu.Unlock()
	return nil
}

type Engine struct {
	cfg       *config.Config
	exchanges map[string]broker.Exchange
	leader    *leader.Fetcher
	store     *store.State
	runtime   *Runtime
	sink      Sink
	notifier  *notify.WeChat
	stop      chan struct{}
}

func New(cfg *config.Config, exchanges map[string]broker.Exchange, lf *leader.Fetcher, st *store.State) *Engine {
	return &Engine{
		cfg: cfg, exchanges: exchanges, leader: lf, store: st,
		runtime: NewRuntime(cfg.Copy), stop: make(chan struct{}),
	}
}

func (e *Engine) Runtime() *Runtime { return e.runtime }

func (e *Engine) SetSink(s Sink) { e.sink = s }

func (e *Engine) SetNotifier(n *notify.WeChat) { e.notifier = n }

func (e *Engine) emit(kind string, payload any) {
	if e.sink != nil {
		e.sink(kind, payload)
	}
}

func (e *Engine) Start(ctx context.Context) {
	go e.loop(ctx)
}

func (e *Engine) Stop() {
	select {
	case <-e.stop:
	default:
		close(e.stop)
	}
}

func (e *Engine) loop(ctx context.Context) {
	tick := time.NewTicker(e.cfg.PollInterval())
	defer tick.Stop()
	e.cycle(ctx)
	for {
		select {
		case <-e.stop:
			return
		case <-ctx.Done():
			return
		case <-tick.C:
			e.cycle(ctx)
		}
	}
}

func (e *Engine) cycle(ctx context.Context) {
	orders, err := e.leader.Latest(ctx)
	if err != nil {
		log.Printf("[copy] fetch leader: %v", err)
		e.emit("leader_error", err.Error())
		return
	}
	e.emit("leader", orders)

	// 通知：独立于跟单开关，检测到新增成交即推送（首轮建立基线不推送）
	if e.notifier != nil {
		e.notifier.NotifyNew(ctx, orders)
	}

	// 按时间正序处理
	sort.SliceStable(orders, func(i, j int) bool { return orders[i].OrderTime < orders[j].OrderTime })

	enabled, margin, leverage, orderType := e.runtime.Snapshot()
	if !enabled {
		// 仍更新游标，避免开启后补一堆历史单
		for _, o := range orders {
			e.store.Mark(orderKey(o))
		}
		e.updateCursor(orders)
		return
	}

	for _, o := range orders {
		key := orderKey(o)
		if e.store.Seen(key) {
			continue
		}
		e.handleOne(ctx, o, margin, leverage, orderType)
		e.store.Mark(key) // 无论成败都标记，防止失败单反复刷屏
	}
	e.updateCursor(orders)
}

func (e *Engine) updateCursor(orders []model.LeaderOrder) {
	for _, o := range orders {
		if o.OrderTime > e.store.GetLastOrderTime() {
			e.store.SetLastOrderTime(o.OrderTime)
		}
	}
}

func orderKey(o model.LeaderOrder) string {
	return fmt.Sprintf("%s|%s|%s|%s|%d|%s|%s",
		o.Symbol, o.Side, o.Type, o.PositionSide, o.OrderTime,
		decimal.NewFromFloat(o.ExecutedQty).String(), decimal.NewFromFloat(o.AvgPrice).String())
}

// handleOne 把一笔带单者成交分发到所有目标交易所（并发）
func (e *Engine) handleOne(ctx context.Context, o model.LeaderOrder, margin string, leverage int, orderType string) {
	action, dir := broker.InferLeaderAction(o.Side, o.PositionSide)
	log.Printf("[copy] 新成交 %s %s %s %s qty=%v price=%v -> 动作=%s 方向=%s",
		o.Symbol, o.Side, o.PositionSide, o.Type, o.ExecutedQty, o.AvgPrice, action, dir)

	targets := e.cfg.Copy.Exchanges
	if len(targets) == 0 {
		for k := range e.exchanges {
			targets = append(targets, k)
		}
	}
	sem := make(chan struct{}, 3)
	var wg sync.WaitGroup
	for _, name := range targets {
		ex, ok := e.exchanges[name]
		if !ok {
			log.Printf("[copy] 目标交易所不存在: %s", name)
			continue
		}
		wg.Add(1)
		sem <- struct{}{}
		go func(ex broker.Exchange) {
			defer wg.Done()
			defer func() { <-sem }()
			rec := e.replicate(ctx, ex, o, action, dir, margin, leverage, orderType)
			e.store.AddCopied(rec)
			e.emit("copied", rec)
		}(ex)
	}
	wg.Wait()
}

// replicate 在单个交易所复制一笔成交
func (e *Engine) replicate(ctx context.Context, ex broker.Exchange, o model.LeaderOrder,
	action broker.Action, dir broker.Direction, margin string, leverage int, orderType string) store.CopiedRec {

	symbol := e.cfg.MapSymbol(o.Symbol, ex.Type())
	rec := store.CopiedRec{
		Key: orderKey(o), Exchange: ex.Name(), Symbol: symbol,
		Action: string(action), PositionSide: string(dir), Time: time.Now().UnixMilli(),
	}

	side, posSide := broker.HedgeParams(action, dir)
	rec.Side = side

	var (
		qty   string
		price string
		err   error
	)
	if action == broker.ActOpen {
		info, e := ex.SymbolInfo(ctx, symbol)
		if e != nil {
			rec.Error = "symbol info: " + e.Error()
			return rec
		}
		// 用带单者均价换算数量；限价单同时按 tickSize 格式化价格
		avgPx := decimal.NewFromFloat(o.AvgPrice).String()
		qty, err = broker.ComputeOpenQty(margin, leverage, avgPx, info)
		if err != nil {
			rec.Error = "compute qty: " + err.Error()
			return rec
		}
		if orderType == "limit" {
			price, err = broker.FormatPrice(avgPx, info.TickSize)
			if err != nil {
				rec.Error = "format price: " + err.Error()
				return rec
			}
		}
		// 单一杠杆来源：下单前显式设置
		if e := ex.SetLeverage(ctx, symbol, leverage); e != nil {
			log.Printf("[copy:%s] set leverage %s x%d: %v", ex.Name(), symbol, leverage, e)
		}
	} else {
		// 平仓：直接全平对应方向持仓（reduceOnly 市价）
		resp, e := ex.ClosePosition(ctx, symbol, posSide)
		if e != nil {
			rec.Error = "close: " + e.Error()
			return rec
		}
		rec.OrderID = resp.OrderID
		rec.Status = resp.Status
		rec.Quantity = "full"
		return rec
	}

	ot := "LIMIT"
	if orderType == "market" {
		ot = "MARKET"
	}
	resp, err := ex.PlaceOrder(ctx, model.OrderReq{
		Symbol: symbol, Side: side, PositionSide: posSide, Type: ot,
		Quantity: qty, Price: price, ReduceOnly: false,
	})
	if err != nil {
		rec.Error = "place order: " + err.Error()
		rec.Quantity = qty
		rec.Price = price
		return rec
	}
	rec.OrderID = resp.OrderID
	rec.Status = resp.Status
	rec.Quantity = qty
	rec.Price = price
	log.Printf("[copy:%s] 已下单 %s %s %s qty=%s price=%s orderId=%s",
		ex.Name(), ot, side, posSide, qty, price, resp.OrderID)
	return rec
}

// 手动下单（供 server 调用），复用同一套参数/精度口径
func (e *Engine) ManualPlace(ctx context.Context, exchangeName string, req model.OrderReq, margin string, leverage int) (*model.OrderResp, error) {
	ex, ok := e.exchanges[exchangeName]
	if !ok {
		return nil, fmt.Errorf("交易所不存在: %s", exchangeName)
	}
	info, err := ex.SymbolInfo(ctx, req.Symbol)
	if err != nil {
		return nil, err
	}
	// 数量规整
	qty, err := broker.FormatQty(req.Quantity, broker.SymbolStep(info), broker.SymbolMinQty(info))
	if err != nil {
		return nil, err
	}
	price := req.Price
	if req.Type == "LIMIT" {
		price, err = broker.FormatPrice(req.Price, info.TickSize)
		if err != nil {
			return nil, err
		}
	}
	// 开仓单设置杠杆；平仓单不设
	if !req.ReduceOnly {
		if e := ex.SetLeverage(ctx, req.Symbol, leverage); e != nil {
			log.Printf("[manual:%s] set leverage %s x%d: %v", exchangeName, req.Symbol, leverage, e)
		}
	}
	placed, err := ex.PlaceOrder(ctx, model.OrderReq{
		Symbol: req.Symbol, Side: req.Side, PositionSide: req.PositionSide,
		Type: req.Type, Quantity: qty, Price: price, ReduceOnly: req.ReduceOnly,
	})
	if err != nil {
		return nil, err
	}
	e.store.AddCopied(store.CopiedRec{
		Key: "manual-" + strconv.FormatInt(time.Now().UnixNano(), 10),
		Exchange: exchangeName, Symbol: req.Symbol, Action: "MANUAL",
		Side: req.Side, PositionSide: req.PositionSide,
		Quantity: qty, Price: price, OrderID: placed.OrderID, Status: placed.Status, Time: time.Now().UnixMilli(),
	})
	e.emit("copied", store.CopiedRec{Exchange: exchangeName, Symbol: req.Symbol, Action: "MANUAL"})
	return placed, nil
}
