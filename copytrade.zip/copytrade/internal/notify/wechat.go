package notify

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"net/url"
	"sync"
	"time"

	"github.com/domigo/copytrade/internal/model"
	"github.com/shopspring/decimal"
)

// WeChat 企业微信群机器人通知器
type WeChat struct {
	enabled bool
	webhook string
	client  *http.Client

	mu       sync.Mutex
	seen     map[string]struct{}
	baseline bool // 首轮是否已建立基线（首轮不推送历史）
	sem      chan struct{}
}

// NewWeChat 创建通知器。webhook 为空或 enabled=false 时不发送。
func NewWeChat(webhook string, enabled bool, proxy string) *WeChat {
	tr := &http.Transport{Proxy: http.ProxyFromEnvironment}
	if proxy != "" {
		if u, err := url.Parse(proxy); err == nil {
			tr.Proxy = http.ProxyURL(u)
		}
	}
	return &WeChat{
		enabled: enabled && webhook != "",
		webhook: webhook,
		client:  &http.Client{Transport: tr, Timeout: 12 * time.Second},
		seen:    make(map[string]struct{}),
		sem:     make(chan struct{}, 2),
	}
}

// Enabled 报告是否启用
func (w *WeChat) Enabled() bool { return w != nil && w.enabled }

// NotifyNew 对比内部已推送集合，对新增成交异步推送企业微信。
// 首次调用只建立基线、不推送，避免启动时把历史成交刷屏。
func (w *WeChat) NotifyNew(ctx context.Context, orders []model.LeaderOrder) {
	if w == nil || !w.enabled || len(orders) == 0 {
		return
	}
	w.mu.Lock()
	defer w.mu.Unlock()

	if !w.baseline {
		for _, o := range orders {
			w.seen[orderKey(o)] = struct{}{}
		}
		w.baseline = true
		log.Printf("[notify:wechat] 已建立基线，当前 %d 条历史成交不推送", len(orders))
		return
	}

	var fresh []model.LeaderOrder
	for _, o := range orders {
		k := orderKey(o)
		if _, ok := w.seen[k]; !ok {
			w.seen[k] = struct{}{}
			fresh = append(fresh, o)
		}
	}
	for _, o := range fresh {
		w.sendAsync(ctx, o)
	}
}

func (w *WeChat) sendAsync(ctx context.Context, o model.LeaderOrder) {
	select {
	case w.sem <- struct{}{}:
	default:
		log.Printf("[notify:wechat] 并发已满，跳过推送 %s %s", o.Symbol, dirCN(o))
		return
	}
	go func() {
		defer func() { <-w.sem }()
		c, cancel := context.WithTimeout(ctx, 12*time.Second)
		defer cancel()
		if err := w.SendText(c, buildTradeMessage(o)); err != nil {
			log.Printf("[notify:wechat] 推送失败 %s %s: %v", o.Symbol, dirCN(o), err)
			return
		}
		log.Printf("[notify:wechat] 已推送新成交 %s %s", o.Symbol, dirCN(o))
	}()
}

// SendText 同步发送一条纯文本消息（供测试端点使用）
func (w *WeChat) SendText(ctx context.Context, content string) error {
	if w == nil || !w.enabled {
		return fmt.Errorf("wechat notify 未启用")
	}
	body, err := json.Marshal(map[string]any{
		"msgtype": "text",
		"text":    map[string]string{"content": content},
	})
	if err != nil {
		return err
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, w.webhook, bytes.NewReader(body))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")
	resp, err := w.client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	b, _ := io.ReadAll(resp.Body)
	var r struct {
		ErrCode int    `json:"errcode"`
		ErrMsg  string `json:"errmsg"`
	}
	_ = json.Unmarshal(b, &r)
	if r.ErrCode != 0 {
		return fmt.Errorf("errcode=%d errmsg=%s body=%s", r.ErrCode, r.ErrMsg, string(b))
	}
	return nil
}

// orderKey 与 engine.orderKey 保持同口径，确保去重一致
func orderKey(o model.LeaderOrder) string {
	return fmt.Sprintf("%s|%s|%s|%s|%d|%s|%s",
		o.Symbol, o.Side, o.Type, o.PositionSide, o.OrderTime,
		decimal.NewFromFloat(o.ExecutedQty).String(), decimal.NewFromFloat(o.AvgPrice).String())
}

func dirCN(o model.LeaderOrder) string {
	switch o.Side + "/" + o.PositionSide {
	case "BUY/LONG":
		return "开多"
	case "SELL/SHORT":
		return "开空"
	case "SELL/LONG":
		return "平多"
	case "BUY/SHORT":
		return "平空"
	default:
		return o.Side + "/" + o.PositionSide
	}
}

func buildTradeMessage(o model.LeaderOrder) string {
	t := time.UnixMilli(o.OrderTime).Format("2006-01-02 15:04:05")
	pnl := decimal.NewFromFloat(o.TotalPnl)
	pnlStr := pnl.String()
	if pnl.IsPositive() {
		pnlStr = "+" + pnlStr
	}
	return fmt.Sprintf(
		"带单者新成交\n"+
			"币对：【%s】\n"+
			"方向：【%s】\n"+
			"类型：%s\n"+
			"数量：%s\n"+
			"成交价：%s\n"+
			"盈亏：%s\n"+
			"时间：%s",
		o.Symbol,
		dirCN(o),
		o.Type,
		decimal.NewFromFloat(o.ExecutedQty).String(),
		decimal.NewFromFloat(o.AvgPrice).String(),
		pnlStr,
		t,
	)
}
