package config

import (
	"fmt"
	"os"
	"time"

	"gopkg.in/yaml.v3"
)

type Admin struct {
	Username     string `yaml:"username"`
	Password     string `yaml:"password"`      // 明文（仅本地简易使用，启动有告警）
	PasswordHash string `yaml:"password_hash"` // bcrypt，优先
}

type Server struct {
	Listen string `yaml:"listen"`
}

type Leader struct {
	BaseURL      string `yaml:"base_url"`
	PortfolioID  string `yaml:"portfolio_id"`
	PollInterval string `yaml:"poll_interval"`
	PageSize     int    `yaml:"page_size"`
	Lookback     string `yaml:"lookback"`
	Proxy        string `yaml:"proxy"`
	Cookies      string `yaml:"cookies"`
	Timeout      string `yaml:"timeout"`
}

type Copy struct {
	Enabled   bool     `yaml:"enabled"`
	MarginUSDT float64 `yaml:"margin_usdt"`
	Leverage  int      `yaml:"leverage"`
	OrderType string   `yaml:"order_type"` // limit / market
	CloseMode string   `yaml:"close_mode"` // full / ratio
	Exchanges []string `yaml:"exchanges"`
}

type WeChatNotify struct {
	Enabled bool   `yaml:"enabled"`
	Webhook string `yaml:"webhook"`
	Proxy   string `yaml:"proxy"` // 可选：发送企业微信时使用的代理
}

type Notify struct {
	WeChat WeChatNotify `yaml:"wechat"`
}

type Exchange struct {
	Name       string `yaml:"name"`
	Type       string `yaml:"type"` // binance / okx
	Testnet    bool   `yaml:"testnet"`
	APIKey     string `yaml:"api_key"`
	APISecret  string `yaml:"api_secret"`
	Passphrase string `yaml:"passphrase"`  // okx
	MarginMode string `yaml:"margin_mode"` // cross / isolated，默认 cross
	Proxy      string `yaml:"proxy"`
}

type Config struct {
	Admin     Admin              `yaml:"admin"`
	Server    Server             `yaml:"server"`
	Leader    Leader             `yaml:"leader"`
	Copy      Copy               `yaml:"copy"`
	Notify    Notify             `yaml:"notify"`
	Exchanges []Exchange         `yaml:"exchanges"`
	SymbolMap map[string]map[string]string `yaml:"symbol_map"`
}

func (c *Config) PollInterval() time.Duration {
	d, err := time.ParseDuration(c.Leader.PollInterval)
	if err != nil || d <= 0 {
		return 5 * time.Second
	}
	return d
}

func (c *Config) Lookback() time.Duration {
	d, err := time.ParseDuration(c.Leader.Lookback)
	if err != nil || d <= 0 {
		return 24 * time.Hour
	}
	return d
}

func (c *Config) LeaderTimeout() time.Duration {
	return c.Leader.TimeoutDur()
}

func (l Leader) TimeoutDur() time.Duration {
	d, err := time.ParseDuration(l.Timeout)
	if err != nil || d <= 0 {
		return 15 * time.Second
	}
	return d
}

func (l Leader) LookbackDur() time.Duration {
	d, err := time.ParseDuration(l.Lookback)
	if err != nil || d <= 0 {
		return 24 * time.Hour
	}
	return d
}

// MapSymbol 把带单者 symbol 映射到目标交易所 symbol；缺省自动推导
func (c *Config) MapSymbol(leaderSymbol, exchType string) string {
	if c.SymbolMap != nil {
		if m, ok := c.SymbolMap[leaderSymbol]; ok {
			if s, ok := m[exchType]; ok && s != "" {
				return s
			}
		}
	}
	switch exchType {
	case "binance":
		return leaderSymbol
	case "okx":
		// BTCUSDT -> BTC-USDT-SWAP（QUOTE 一般为 USDT）
		for _, q := range []string{"USDT", "USDC", "BUSD"} {
			if len(leaderSymbol) > len(q) && leaderSymbol[len(leaderSymbol)-len(q):] == q {
				base := leaderSymbol[:len(leaderSymbol)-len(q)]
				return base + "-" + q + "-SWAP"
			}
		}
		return leaderSymbol
	}
	return leaderSymbol
}

func Load(path string) (*Config, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read config %s: %w", path, err)
	}
	var c Config
	if err := yaml.Unmarshal(b, &c); err != nil {
		return nil, fmt.Errorf("parse config: %w", err)
	}
	c.applyDefaults()
	if err := c.validate(); err != nil {
		return nil, err
	}
	return &c, nil
}

func (c *Config) applyDefaults() {
	if c.Server.Listen == "" {
		c.Server.Listen = ":8080"
	}
	if c.Leader.BaseURL == "" {
		c.Leader.BaseURL = "https://www.binance.com"
	}
	if c.Leader.PageSize <= 0 {
		c.Leader.PageSize = 20
	}
	if c.Leader.PollInterval == "" {
		c.Leader.PollInterval = "5s"
	}
	if c.Leader.Lookback == "" {
		c.Leader.Lookback = "24h"
	}
	if c.Leader.Timeout == "" {
		c.Leader.Timeout = "15s"
	}
	if c.Copy.MarginUSDT <= 0 {
		c.Copy.MarginUSDT = 100
	}
	if c.Copy.Leverage <= 0 {
		c.Copy.Leverage = 10
	}
	if c.Copy.OrderType == "" {
		c.Copy.OrderType = "limit"
	}
	if c.Copy.CloseMode == "" {
		c.Copy.CloseMode = "full"
	}
	// 企业微信通知：默认带单者新成交推送到指定 webhook；置空 webhook 可关闭
	if c.Notify.WeChat.Webhook == "" {
		c.Notify.WeChat.Webhook = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=68af0579-1187-44ba-a3b5-ca4233bce82b"
	}
	if c.Notify.WeChat.Webhook != "" {
		c.Notify.WeChat.Enabled = true
	}
}

func (c *Config) validate() error {
	if c.Admin.Username == "" {
		return fmt.Errorf("admin.username 不能为空")
	}
	if c.Admin.Password == "" && c.Admin.PasswordHash == "" {
		return fmt.Errorf("admin.password 或 admin.password_hash 必须设置一个")
	}
	if c.Leader.PortfolioID == "" {
		return fmt.Errorf("leader.portfolio_id 不能为空")
	}
	if len(c.Exchanges) == 0 {
		return fmt.Errorf("exchanges 不能为空")
	}
	seen := map[string]bool{}
	for i, e := range c.Exchanges {
		if e.Name == "" {
			return fmt.Errorf("exchanges[%d].name 不能为空", i)
		}
		if seen[e.Name] {
			return fmt.Errorf("exchanges name 重复: %s", e.Name)
		}
		seen[e.Name] = true
		if e.Type != "binance" && e.Type != "okx" {
			return fmt.Errorf("exchanges[%d].type 只能是 binance 或 okx", i)
		}
	}
	return nil
}
