package leader

import (
	"context"
	"os"
	"testing"
	"time"

	"github.com/domigo/copytrade/internal/config"
)

// 运行：PROXY=http://127.0.0.1:7890 go test ./internal/leader/ -run TestFetch -v
// 未设置 PROXY 时跳过（避免在无代理环境下挂起）
func TestFetch(t *testing.T) {
	proxy := os.Getenv("PROXY")
	if proxy == "" {
		t.Skip("PROXY 环境变量未设置，跳过带单者接口联调测试")
	}
	cfg := config.Leader{
		BaseURL:     "https://www.binance.com",
		PortfolioID: "5075281354358777856",
		PageSize:    10,
		Lookback:    "24h",
		Timeout:     "15s",
		Proxy:       proxy,
	}
	f := New(cfg)
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()

	end := time.Now().UnixMilli()
	start := time.Now().Add(-24 * time.Hour).UnixMilli()
	orders, err := f.Fetch(ctx, start, end)
	if err != nil {
		t.Fatalf("fetch failed: %v", err)
	}
	t.Logf("fetched %d orders", len(orders))
	for i, o := range orders {
		if i >= 3 {
			break
		}
		t.Logf("  %s %s %s %s qty=%v price=%v time=%d",
			o.Symbol, o.Side, o.PositionSide, o.Type, o.ExecutedQty, o.AvgPrice, o.OrderTime)
	}
}
