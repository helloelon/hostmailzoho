package leader

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"net/url"
	"time"

	"github.com/domigo/copytrade/internal/config"
	"github.com/domigo/copytrade/internal/model"
)

const orderHistoryPath = "/bapi/futures/v1/friendly/future/copy-trade/lead-portfolio/order-history"

const ua = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

type Fetcher struct {
	cfg  config.Leader
	hc   *http.Client
	last []model.LeaderOrder // 最近一次拉取结果，供 UI 展示
}

func New(cfg config.Leader) *Fetcher {
	hc := &http.Client{Timeout: cfg.TimeoutDur()}
	if cfg.Proxy != "" {
		if p, err := url.Parse(cfg.Proxy); err == nil {
			hc.Transport = &http.Transport{Proxy: http.ProxyURL(p)}
		} else {
			log.Printf("[leader] proxy 解析失败: %v", err)
		}
	}
	return &Fetcher{cfg: cfg, hc: hc}
}

// Latest 拉取最近 lookback 时间窗口内的成交记录
func (f *Fetcher) Latest(ctx context.Context) ([]model.LeaderOrder, error) {
	end := time.Now().UnixMilli()
	start := time.Now().Add(-f.cfg.LookbackDur()).UnixMilli()
	return f.Fetch(ctx, start, end)
}

// Fetch 按时间范围拉取
func (f *Fetcher) Fetch(ctx context.Context, startTime, endTime int64) ([]model.LeaderOrder, error) {
	body := map[string]any{
		"portfolioId": f.cfg.PortfolioID,
		"startTime":   startTime,
		"endTime":     endTime,
		"pageSize":    f.cfg.PageSize,
	}
	raw, err := json.Marshal(body)
	if err != nil {
		return nil, err
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, f.cfg.BaseURL+orderHistoryPath, bytes.NewReader(raw))
	if err != nil {
		return nil, err
	}
	req.Header.Set("User-Agent", ua)
	req.Header.Set("Accept", "application/json, text/plain, */*")
	req.Header.Set("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.8")
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Origin", "https://www.binance.com")
	req.Header.Set("Referer", "https://www.binance.com/")
	req.Header.Set("clienttype", "web")
	req.Header.Set("lang", "zh-CN")
	if f.cfg.Cookies != "" {
		req.Header.Set("Cookie", f.cfg.Cookies)
	}

	resp, err := f.hc.Do(req)
	if err != nil {
		return nil, fmt.Errorf("leader request: %w", err)
	}
	defer resp.Body.Close()
	respBody, _ := io.ReadAll(resp.Body)
	if resp.StatusCode >= 400 {
		return nil, fmt.Errorf("leader http %d: %s", resp.StatusCode, truncate(string(respBody), 300))
	}

	var r model.LeaderResp
	if err := json.Unmarshal(respBody, &r); err != nil {
		return nil, fmt.Errorf("leader decode: %w; body=%s", err, truncate(string(respBody), 300))
	}
	if r.Code != "000000" || !r.Success {
		return nil, fmt.Errorf("leader api error code=%s success=%v body=%s", r.Code, r.Success, truncate(string(respBody), 300))
	}
	f.last = r.Data.List
	return r.Data.List, nil
}

// Last 返回最近一次拉取结果（供 UI 展示）
func (f *Fetcher) Last() []model.LeaderOrder {
	return f.last
}

func truncate(s string, n int) string {
	if len(s) <= n {
		return s
	}
	return s[:n] + "..."
}
