package store

import (
	"encoding/json"
	"os"
	"sync"
)

// CopiedRec 记录一笔跟单落地结果，便于对账与 UI 展示
type CopiedRec struct {
	Key          string `json:"key"`
	Exchange     string `json:"exchange"`
	Symbol       string `json:"symbol"`
	Action       string `json:"action"` // OPEN / CLOSE
	Side         string `json:"side"`
	PositionSide string `json:"positionSide"`
	Quantity     string `json:"quantity"`
	Price        string `json:"price"`
	OrderID      string `json:"orderId"`
	Status       string `json:"status"`
	Time         int64  `json:"time"`
	Error        string `json:"error,omitempty"`
}

type State struct {
	mu            sync.RWMutex
	path          string
	ProcessedKeys map[string]bool `json:"processed_keys"`
	LastOrderTime int64           `json:"last_order_time"`
	Copied        []CopiedRec     `json:"copied"`
}

func Load(path string) (*State, error) {
	s := &State{path: path, ProcessedKeys: map[string]bool{}}
	b, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			return s, nil
		}
		return nil, err
	}
	if len(b) == 0 {
		return s, nil
	}
	if err := json.Unmarshal(b, s); err != nil {
		return nil, err
	}
	if s.ProcessedKeys == nil {
		s.ProcessedKeys = map[string]bool{}
	}
	return s, nil
}

func (s *State) saveLocked() error {
	b, err := json.MarshalIndent(s, "", "  ")
	if err != nil {
		return err
	}
	tmp := s.path + ".tmp"
	if err := os.WriteFile(tmp, b, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, s.path)
}

func (s *State) Save() error {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.saveLocked()
}

func (s *State) Seen(key string) bool {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.ProcessedKeys[key]
}

func (s *State) Mark(key string) {
	s.mu.Lock()
	s.ProcessedKeys[key] = true
	s.saveLocked()
	s.mu.Unlock()
}

func (s *State) SetLastOrderTime(t int64) {
	s.mu.Lock()
	if t > s.LastOrderTime {
		s.LastOrderTime = t
	}
	s.saveLocked()
	s.mu.Unlock()
}

func (s *State) GetLastOrderTime() int64 {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.LastOrderTime
}

func (s *State) AddCopied(r CopiedRec) {
	s.mu.Lock()
	s.Copied = append(s.Copied, r)
	// 只保留最近 500 条，避免文件无限增长
	if len(s.Copied) > 500 {
		s.Copied = s.Copied[len(s.Copied)-500:]
	}
	s.saveLocked()
	s.mu.Unlock()
}

func (s *State) CopiedList() []CopiedRec {
	s.mu.RLock()
	defer s.mu.RUnlock()
	out := make([]CopiedRec, len(s.Copied))
	copy(out, s.Copied)
	return out
}
