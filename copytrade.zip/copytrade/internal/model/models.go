package model

// 带单者成交记录（来自 Binance BAPI order-history）
type LeaderOrder struct {
	Symbol          string  `json:"symbol"`
	BaseAsset       string  `json:"baseAsset"`
	QuoteAsset      string  `json:"quoteAsset"`
	Side            string  `json:"side"`              // BUY / SELL
	Type            string  `json:"type"`              // LIMIT / MARKET
	PositionSide    string  `json:"positionSide"`      // LONG / SHORT
	ExecutedQty     float64 `json:"executedQty"`
	AvgPrice        float64 `json:"avgPrice"`
	TotalPnl        float64 `json:"totalPnl"`
	OrderUpdateTime int64   `json:"orderUpdateTime"`
	OrderTime       int64   `json:"orderTime"`
}

type LeaderResp struct {
	Code    string  `json:"code"`
	Message *string `json:"message"`
	Success bool    `json:"success"`
	Data    struct {
		IndexValue string        `json:"indexValue"`
		Total      int           `json:"total"`
		List       []LeaderOrder `json:"list"`
	} `json:"data"`
}

// 交易所下单请求（内部统一模型）
type OrderReq struct {
	Symbol       string  // 交易所原始交易对（如 BTCUSDT 或 BTC-USDT-SWAP）
	Side         string  // BUY / SELL
	PositionSide string  // LONG / SHORT（双向持仓必填）
	Type         string  // LIMIT / MARKET
	Quantity     string  // 数量（已按精度格式化的字符串）
	Price        string  // 价格（限价必填，已格式化；市价可为空）
	ReduceOnly   bool    // 平仓单
	ClientOrderID string // 可选
}

type OrderResp struct {
	Exchange      string
	Symbol        string
	OrderID       string
	ClientOrderID string
	Status        string // NEW / FILLED / CANCELED / PARTIALLY_FILLED 等
	Msg           string
}

// 持仓
type Position struct {
	Exchange      string  `json:"exchange"`
	Symbol        string  `json:"symbol"`
	PositionSide  string  `json:"positionSide"`
	Quantity      string  `json:"quantity"`
	EntryPrice    string  `json:"entryPrice"`
	MarkPrice     string  `json:"markPrice"`
	UnrealizedPnl string  `json:"unrealizedPnl"`
	Leverage      int     `json:"leverage"`
	MarginType    string  `json:"marginType"`
}

// 挂单（未成交）
type OpenOrder struct {
	Exchange      string  `json:"exchange"`
	Symbol        string  `json:"symbol"`
	OrderID       string  `json:"orderId"`
	ClientOrderID string  `json:"clientOrderId"`
	Side          string  `json:"side"`
	PositionSide  string  `json:"positionSide"`
	Type          string  `json:"type"`
	Quantity      string  `json:"quantity"`
	Price         string  `json:"price"`
	ReduceOnly    bool    `json:"reduceOnly"`
	Status        string  `json:"status"`
	Time          int64   `json:"time"`
}

// 交易对精度与约束
type SymbolInfo struct {
	Symbol      string
	TickSize    string // 价格步进
	StepSize    string // 数量步进（币安）
	MinQty      string // 最小数量
	MinNotional string // 最小名义价值
	CtVal       string // OKX 合约面值
	LotSz       string // OKX 数量步进
}
