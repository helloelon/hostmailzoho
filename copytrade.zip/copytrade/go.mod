module github.com/domigo/copytrade

go 1.22

require (
	github.com/shopspring/decimal v1.4.0
	gopkg.in/yaml.v3 v3.0.1
)

require golang.org/x/crypto v0.31.0 // indirect
