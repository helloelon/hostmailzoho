package main

import (
	"context"
	"flag"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/domigo/copytrade/internal/broker"
	"github.com/domigo/copytrade/internal/broker/binance"
	"github.com/domigo/copytrade/internal/broker/okx"
	"github.com/domigo/copytrade/internal/config"
	"github.com/domigo/copytrade/internal/copy"
	"github.com/domigo/copytrade/internal/leader"
	"github.com/domigo/copytrade/internal/notify"
	"github.com/domigo/copytrade/internal/server"
	"github.com/domigo/copytrade/internal/store"
	"golang.org/x/crypto/bcrypt"
)

func main() {
	cfgPath := flag.String("config", "config.yaml", "配置文件路径")
	statePath := flag.String("state", "state.json", "状态快照文件路径")
	hashPwd := flag.String("hash", "", "生成密码的 bcrypt 哈希并退出")
	flag.Parse()

	if *hashPwd != "" {
		h, err := bcrypt.GenerateFromPassword([]byte(*hashPwd), bcrypt.DefaultCost)
		if err != nil {
			log.Fatal(err)
		}
		fmt.Println(string(h))
		return
	}

	cfg, err := config.Load(*cfgPath)
	if err != nil {
		log.Fatalf("加载配置失败: %v", err)
	}
	if cfg.Admin.PasswordHash == "" && cfg.Admin.Password != "" {
		log.Println("[警告] 当前使用明文密码，建议用 -hash 生成 bcrypt 哈希后填入 admin.password_hash")
	}

	// 初始化交易所客户端（单个失败只告警跳过，不影响整体启动）
	exchanges := map[string]broker.Exchange{}
	for _, ec := range cfg.Exchanges {
		var ex broker.Exchange
		switch ec.Type {
		case "binance":
			ex, err = binance.New(ec)
		case "okx":
			ex, err = okx.New(ec)
		default:
			err = fmt.Errorf("未知交易所类型: %s", ec.Type)
		}
		if err != nil {
			log.Printf("[警告] 跳过交易所 %s: %v", ec.Name, err)
			continue
		}
		exchanges[ec.Name] = ex
		log.Printf("[init] 交易所就绪: %s (%s, testnet=%v)", ec.Name, ec.Type, ec.Testnet)
	}
	if len(exchanges) == 0 {
		log.Println("[警告] 没有可用的交易所，仅启动带单者数据展示与管理页面")
	}

	lf := leader.New(cfg.Leader)
	st, err := store.Load(*statePath)
	if err != nil {
		log.Fatalf("加载状态失败: %v", err)
	}
	notifier := notify.NewWeChat(cfg.Notify.WeChat.Webhook, cfg.Notify.WeChat.Enabled, cfg.Notify.WeChat.Proxy)
	if notifier.Enabled() {
		log.Println("[init] 企业微信通知已启用")
	} else {
		log.Println("[init] 企业微信通知未启用（未配置 webhook）")
	}
	engine := copy.New(cfg, exchanges, lf, st)
	engine.SetNotifier(notifier)
	srv := server.New(cfg, engine, exchanges, lf, st, notifier)

	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	engine.Start(ctx)
	srv.Start(ctx)

	httpSrv := &http.Server{Addr: cfg.Server.Listen, Handler: srv.Handler(), ReadHeaderTimeout: 10 * time.Second}
	go func() {
		log.Printf("[server] 监听 %s", cfg.Server.Listen)
		if err := httpSrv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("HTTP 服务错误: %v", err)
		}
	}()

	<-ctx.Done()
	log.Println("正在关闭...")
	engine.Stop()
	shutdownCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	_ = httpSrv.Shutdown(shutdownCtx)
	_ = st.Save()
	log.Println("已退出")
	os.Exit(0)
}
